use master
if(exists(select * from master.dbo.sysdatabases where name = 'Library'))
begin
print '�Ѵ������ݿ�Library,ɾ���ؽ��С�����'

drop database Library
end
go
create database Library
go
use Library
go


create table LogInfo
(
	tno bigint identity(1,1) primary key,
	username char(20),
	passwd char(30),
	Logid char(6),
	check (Logid='admin' OR Logid='reader')
)


create table Books
(
	
	ISBNum char(10) primary key,
	bname char(20) not null,
	bpress char(20),
	bwriter char(10),
	bnumAll int,
	bnumAvailable int,
	bifAvailable char(5),
	check(bnumAll>=0 AND bnumAvailable >=0)
	
)
alter table Books add
constraint de_Books_Ifavailable default '�ɽ�' for bifAvailable

create table Readers
(
	rid char(20) primary key,
	rname char(20) not null,
	rsex char(2),
	rjob char(10),
	ravailable int,
	ralready int,
	rworkplace char(20),
	rtel char(11),
	check (rsex = '��'OR rsex ='Ů' )
)
alter table Readers add
constraint de_Readers_rsex default '��' for rsex

create table BR
(
	BRno bigint identity(1,1) primary key,
	ISBNum char(10),
	rid char(20),
	CheckOutDate date,
	DeadLine date,
	ReturnDate date,
	fine money,
	constraint FK_BR_BOOKS foreign key(ISBNum)
	references Books(ISBNum)
	on update cascade
	on delete cascade,
	constraint FK_BR_READERS foreign key(rid)
	references Readers(rid)
	on update cascade
	on delete cascade,
	check (fine>=0)
)
alter table BR add
constraint de_BR_fine default 0 for fine

exec sp_addrole 'Lbry_admin'
exec sp_addrole 'Lbry_reader'

grant all on Books to Lbry_admin with grant option
grant all on BR to Lbry_admin with grant option
grant all on LogInfo to Lbry_admin with grant option
grant all on Readers to Lbry_admin with grant option

grant select,update on Books to Lbry_reader
grant select,update on Readers to Lbry_reader
grant select,update,insert,delete on BR to Lbry_reader
grant select,insert,update,delete on LogInfo to Lbry_reader

alter table LogInfo add constraint uniuserName unique(username)

use master
if(exists(select * from master.dbo.syslogins where name = 'tutu'))
begin
exec sp_droplogin 'tutu'
exec sp_dropuser 'tutu'
end

if(exists(select * from master.dbo.syslogins where name = 'ding'))
begin
exec sp_droplogin 'ding'
exec sp_dropuser 'ding'
end

exec sp_addlogin 'tutu','123456','Library'
exec sp_adduser 'tutu','tutu'
EXEC master.dbo.sp_addsrvrolemember @loginame = N'tutu',   @rolename = N'sysadmin'
exec sp_addrolemember 'Lbry_admin','tutu'




exec sp_addlogin 'ding','654321','Library'
exec sp_adduser 'ding','ding'
EXEC master.dbo.sp_addsrvrolemember @loginame = N'ding',   @rolename = N'sysadmin'
exec sp_addrolemember 'Lbry_admin','ding'





print '���ݿ��ʼ�����,����select * from LogInfo �鿴��ʼ���û���Ϣ'

use Library

insert into Books values ('1234567890','tubook','tupress','tutu',100,20,'��')
insert into Books values ('0987654321','DIngbook','dingpress','ding',100,20,'��')
insert into Readers values ('22920172204175','tutu','��','ѧ��',5,20,'ѧУ','18120757777')
insert into Readers values ('2292017220235','ding','��','ѧ��',5,20,'ѧУ','13220721177')
insert into BR(ISBNum,rid,CheckOutDate,DeadLine,ReturnDate,fine) values ('1234567890','22920172204175','2020-01-01','2020-06-04','','0.00')
insert into BR(ISBNum,rid,CheckOutDate,DeadLine,ReturnDate,fine) values ('0987654321','2292017220235','2020-01-02','2020-06-05','','0.00')

select * from Books
select * from Readers
select * from BR

insert into LogInfo(username,passwd,Logid)
values('tutu','123456','admin')
insert into LogInfo(username,passwd,Logid)
values('ding','654321','admin')
select * from LogInfo

if exists(select * from sys.procedures where name='OverDueInfo')
drop procedure dbo.OverDueInfo
go
create procedure OverDueInfo
	@Rid char(20)
as
begin
	
	begin
		select ISBNum as 'ISBN���',bname as '����',rname as '��������' from Books,Readers
			where exists(select * from BR where  DeadLine <=  DATENAME(YEAR,GETDATE())+'/'+DATENAME(MONTH,GETDATE())+'/'+DATENAME(DAY,GETDATE()) and BR.ISBNum = Books.ISBNum and BR.rid = @Rid and Readers.rid = @Rid)
	end
end


if exists(select * from sys.procedures where name='OverDueBooks')
drop procedure dbo.OverDueBooks
go
create procedure OverDueBooks
	@Rid char(20)
as
begin
	
	begin
		select *
		from BR
		where  
			DeadLine <=  DATENAME(YEAR,GETDATE())+'/'
			+DATENAME(MONTH,GETDATE())+'/'+DATENAME(DAY,GETDATE()) 
			and ReturnDate = '1900/1/1'
			and BR.rid = @Rid
	end
end


if(OBJECT_ID('ifAvilable') is not null)        
drop trigger ifAvilable       
go
create trigger ifAvilable
on Books for update as
declare @numAvailable int = 1
declare @ISBNum char(10)
	select @numAvailable = bnumAvailable,@ISBNum = ISBNum from inserted 
	if(@numAvailable > 0)
		update Books set bifAvailable = '��'  where ISBNum = @ISBNum
	else
		update Books set bifAvailable = '��' where ISBNum = @ISBNum
		
		
go
if(OBJECT_ID('deleteReader') is not null)       
drop trigger deleteReader       
go
create trigger deleteReader
on Readers for delete as
declare @Rname char(20)
	select @Rname = rname from deleted 
	delete from LogInfo where username = @Rname


