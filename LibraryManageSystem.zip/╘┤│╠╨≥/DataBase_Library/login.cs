﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            publicVar.currentConnection.ConnectionString = String.Format("server=localhost;database=Library;uid={0};pwd={1}", username_text.Text.Trim(), passwd_text.Text);
            try
            {
                publicVar.currentConnection.Open();
            }
            catch (InvalidOperationException IOE)
            {
                if (MessageBox.Show(IOE.Message, "无效操作！", MessageBoxButtons.OK, MessageBoxIcon.Error) == DialogResult.OK)
                    return;
            }
            catch (SqlException SqlE)
            {
                if (MessageBox.Show(SqlE.Message, "数据库链接错误！", MessageBoxButtons.OK, MessageBoxIcon.Error) == DialogResult.OK)
                    return;
            }
            string sql = String.Format("select Logid from LogInfo where username='{0}'", username_text.Text.Trim());
            DataSet result = DBoperations.Query(sql);
            Console.WriteLine("调试中的debugNumber: " + result.Tables["ds"].Rows[0]["Logid"].ToString());
            string loginId = result.Tables["ds"].Rows[0]["Logid"].ToString().Trim();
            if(MessageBox.Show("成功登陆！") == DialogResult.OK)
            {
                publicVar.currentUser = username_text.Text.Trim();
                publicVar.currentPasswd = passwd_text.Text;
                Console.WriteLine("\n\n调试中的debugNumber: ++++++++++++++++++++++++++++++++++++++++\n\n");
                if (loginId.Contains("admin"))
                {
                    Console.WriteLine("\n\n调试中的debugNumber: ++++++++++++++++++++++++++++++++++++++++\n\n");
                    publicVar.currentStatu = publicVar.Status.Admin;
                    ReadersForm_admin childrenForm_admin = new ReadersForm_admin();
                    childrenForm_admin.Owner = this;
                    childrenForm_admin.Show(this);
                 
                    this.Hide();
                }
                else
                {
                    publicVar.currentStatu = publicVar.Status.Reader;
                    ReadersForm_reader childrenForm_reader = new ReadersForm_reader();
                    childrenForm_reader.Owner = this;
                    childrenForm_reader.Show(this);
                    
                    this.Hide();
                }
                
            }
        }

        private void signin_button_Click(object sender, EventArgs e)
        {
            signin childrenForm_signin = new signin();
            childrenForm_signin.Owner = this;
            childrenForm_signin.Show();
        }

        private void login_Load(object sender, EventArgs e)
        {
            this.Text = "登录";
        }
    }
}
