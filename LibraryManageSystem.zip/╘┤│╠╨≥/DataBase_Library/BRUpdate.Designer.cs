﻿namespace DataBase_Library
{
    partial class BRUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.update_group = new System.Windows.Forms.GroupBox();
            this.rid_text = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CheckOutDate_text = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.ReturnDate_text = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.DeadLine_text = new System.Windows.Forms.DateTimePicker();
            this.fine_text = new System.Windows.Forms.TextBox();
            this.ISBNum_text = new System.Windows.Forms.TextBox();
            this.presslabel6 = new System.Windows.Forms.Label();
            this.collectionnumlabel6 = new System.Windows.Forms.Label();
            this.yesnoborrowlabel6 = new System.Windows.Forms.Label();
            this.writerlabel6 = new System.Windows.Forms.Label();
            this.ISBNlabel6 = new System.Windows.Forms.Label();
            this.reset_btn = new System.Windows.Forms.Button();
            this.update_cancel = new System.Windows.Forms.Button();
            this.update_confirm = new System.Windows.Forms.Button();
            this.update_group.SuspendLayout();
            this.SuspendLayout();
            // 
            // update_group
            // 
            this.update_group.Controls.Add(this.rid_text);
            this.update_group.Controls.Add(this.label3);
            this.update_group.Controls.Add(this.CheckOutDate_text);
            this.update_group.Controls.Add(this.label2);
            this.update_group.Controls.Add(this.ReturnDate_text);
            this.update_group.Controls.Add(this.label1);
            this.update_group.Controls.Add(this.DeadLine_text);
            this.update_group.Controls.Add(this.fine_text);
            this.update_group.Controls.Add(this.ISBNum_text);
            this.update_group.Controls.Add(this.presslabel6);
            this.update_group.Controls.Add(this.collectionnumlabel6);
            this.update_group.Controls.Add(this.yesnoborrowlabel6);
            this.update_group.Controls.Add(this.writerlabel6);
            this.update_group.Controls.Add(this.ISBNlabel6);
            this.update_group.Location = new System.Drawing.Point(63, 109);
            this.update_group.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_group.Name = "update_group";
            this.update_group.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_group.Size = new System.Drawing.Size(824, 140);
            this.update_group.TabIndex = 19;
            this.update_group.TabStop = false;
            this.update_group.Text = "查询条件";
            // 
            // rid_text
            // 
            this.rid_text.Location = new System.Drawing.Point(122, 86);
            this.rid_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rid_text.Name = "rid_text";
            this.rid_text.Size = new System.Drawing.Size(112, 28);
            this.rid_text.TabIndex = 26;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(628, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(188, 18);
            this.label3.TabIndex = 24;
            this.label3.Text = "是否逾期结果自动生成";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // CheckOutDate_text
            // 
            this.CheckOutDate_text.Location = new System.Drawing.Point(439, 34);
            this.CheckOutDate_text.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.CheckOutDate_text.Name = "CheckOutDate_text";
            this.CheckOutDate_text.Size = new System.Drawing.Size(165, 28);
            this.CheckOutDate_text.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(436, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "借出日期";
            // 
            // ReturnDate_text
            // 
            this.ReturnDate_text.Location = new System.Drawing.Point(439, 96);
            this.ReturnDate_text.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.ReturnDate_text.Name = "ReturnDate_text";
            this.ReturnDate_text.Size = new System.Drawing.Size(165, 28);
            this.ReturnDate_text.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(436, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "返还日期";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // DeadLine_text
            // 
            this.DeadLine_text.Location = new System.Drawing.Point(638, 34);
            this.DeadLine_text.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.DeadLine_text.Name = "DeadLine_text";
            this.DeadLine_text.Size = new System.Drawing.Size(178, 28);
            this.DeadLine_text.TabIndex = 19;
            // 
            // fine_text
            // 
            this.fine_text.Location = new System.Drawing.Point(306, 86);
            this.fine_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fine_text.Name = "fine_text";
            this.fine_text.Size = new System.Drawing.Size(112, 28);
            this.fine_text.TabIndex = 10;
            // 
            // ISBNum_text
            // 
            this.ISBNum_text.Location = new System.Drawing.Point(307, 26);
            this.ISBNum_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ISBNum_text.Name = "ISBNum_text";
            this.ISBNum_text.Size = new System.Drawing.Size(112, 28);
            this.ISBNum_text.TabIndex = 8;
            // 
            // presslabel6
            // 
            this.presslabel6.AutoSize = true;
            this.presslabel6.Location = new System.Drawing.Point(256, 93);
            this.presslabel6.Name = "presslabel6";
            this.presslabel6.Size = new System.Drawing.Size(44, 18);
            this.presslabel6.TabIndex = 5;
            this.presslabel6.Text = "罚款";
            // 
            // collectionnumlabel6
            // 
            this.collectionnumlabel6.AutoSize = true;
            this.collectionnumlabel6.Location = new System.Drawing.Point(635, 13);
            this.collectionnumlabel6.Name = "collectionnumlabel6";
            this.collectionnumlabel6.Size = new System.Drawing.Size(80, 18);
            this.collectionnumlabel6.TabIndex = 3;
            this.collectionnumlabel6.Text = "截止日期";
            // 
            // yesnoborrowlabel6
            // 
            this.yesnoborrowlabel6.AutoSize = true;
            this.yesnoborrowlabel6.Location = new System.Drawing.Point(37, 96);
            this.yesnoborrowlabel6.Name = "yesnoborrowlabel6";
            this.yesnoborrowlabel6.Size = new System.Drawing.Size(80, 18);
            this.yesnoborrowlabel6.TabIndex = 2;
            this.yesnoborrowlabel6.Text = "读者卡号";
            // 
            // writerlabel6
            // 
            this.writerlabel6.AutoSize = true;
            this.writerlabel6.Location = new System.Drawing.Point(238, 31);
            this.writerlabel6.Name = "writerlabel6";
            this.writerlabel6.Size = new System.Drawing.Size(62, 18);
            this.writerlabel6.TabIndex = 1;
            this.writerlabel6.Text = "ISBN号";
            // 
            // ISBNlabel6
            // 
            this.ISBNlabel6.AutoSize = true;
            this.ISBNlabel6.Location = new System.Drawing.Point(37, 32);
            this.ISBNlabel6.Name = "ISBNlabel6";
            this.ISBNlabel6.Size = new System.Drawing.Size(152, 18);
            this.ISBNlabel6.TabIndex = 0;
            this.ISBNlabel6.Text = "信息序号默认自增";
            // 
            // reset_btn
            // 
            this.reset_btn.Location = new System.Drawing.Point(802, 256);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(85, 33);
            this.reset_btn.TabIndex = 20;
            this.reset_btn.Text = "复位";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // update_cancel
            // 
            this.update_cancel.Location = new System.Drawing.Point(622, 349);
            this.update_cancel.Name = "update_cancel";
            this.update_cancel.Size = new System.Drawing.Size(118, 43);
            this.update_cancel.TabIndex = 22;
            this.update_cancel.Text = "取消";
            this.update_cancel.UseVisualStyleBackColor = true;
            this.update_cancel.Click += new System.EventHandler(this.update_cancel_Click);
            // 
            // update_confirm
            // 
            this.update_confirm.Location = new System.Drawing.Point(245, 349);
            this.update_confirm.Name = "update_confirm";
            this.update_confirm.Size = new System.Drawing.Size(118, 43);
            this.update_confirm.TabIndex = 21;
            this.update_confirm.Text = "确认";
            this.update_confirm.UseVisualStyleBackColor = true;
            this.update_confirm.Click += new System.EventHandler(this.update_confirm_Click);
            // 
            // BRUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1007, 503);
            this.Controls.Add(this.update_cancel);
            this.Controls.Add(this.update_confirm);
            this.Controls.Add(this.reset_btn);
            this.Controls.Add(this.update_group);
            this.Name = "BRUpdate";
            this.Text = "BRUpdate";
            this.Load += new System.EventHandler(this.BRUpdate_Load);
            this.update_group.ResumeLayout(false);
            this.update_group.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox update_group;
        private System.Windows.Forms.TextBox rid_text;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker CheckOutDate_text;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker ReturnDate_text;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker DeadLine_text;
        private System.Windows.Forms.TextBox fine_text;
        private System.Windows.Forms.TextBox ISBNum_text;
        private System.Windows.Forms.Label presslabel6;
        private System.Windows.Forms.Label collectionnumlabel6;
        private System.Windows.Forms.Label yesnoborrowlabel6;
        private System.Windows.Forms.Label writerlabel6;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.Button update_cancel;
        private System.Windows.Forms.Button update_confirm;
        private System.Windows.Forms.Label ISBNlabel6;
    }
}