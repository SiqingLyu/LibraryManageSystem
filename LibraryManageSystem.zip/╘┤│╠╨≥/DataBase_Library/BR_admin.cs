﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class BR_admin : Form
    {
        public string sql_default = "select * from BR where BRno = '-1'";
        public string Mindt = "1900/1/1";
        

        public BR_admin()
        {
            InitializeComponent();
           
            BRno_text.Text = "";
            ISBNum_text.Text = "";
            rid_text.Text = "";
            CheckOutDate_text.Text = Mindt;
            DeadLine_text.Text = Mindt;
            ReturnDate_text.Text = Mindt;
            fine_text.Text = "0";
            ifOverdue_combo.Text = "否";
            update_btn.Enabled = false;
            delete_btn.Enabled = false;
        }

        private void collectionnumlabel6_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Readers_Click(object sender, EventArgs e)
        {
            ReadersForm_admin childrenForm_Readers = new ReadersForm_admin();
            childrenForm_Readers.Show();
            this.Dispose();
        }

        private void Books_Click(object sender, EventArgs e)
        {
            BooksFrom_admin childrenForm_Books = new BooksFrom_admin();
            childrenForm_Books.Show();
            this.Dispose();
        }

        private void BR_admin_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.FormClosing -= BR_admin_FormClosing;
            Application.Exit();
        }

        private void select_btn_Click(object sender, EventArgs e)
        {
            string[] like_equal = { "= '","= '","= '"};
            string BRnoStr = BRno_text.Text.Trim();
            string ISBNStr = ISBNum_text.Text.Trim();
            string ridStr = rid_text.Text.Trim();
            //string CheckOutStr = CheckOutDate_text.Text.Trim();
            //string DeadLineStr = DeadLine_text.Text.Trim();
            //string ReturnStr = ReturnDate_text.Text.Trim();
            string CheckOutStr = CheckOutDate_text.Value.ToShortDateString().ToString().Trim();
            string DeadLineStr = DeadLine_text.Value.ToShortDateString().ToString().Trim();
            string ReturnStr = ReturnDate_text.Value.ToShortDateString().ToString().Trim();
            
            string fineStr = fine_text.Text.Trim();
            Console.WriteLine("\n\n********************调试中的debugNumber:语句：{0}********************\n", CheckOutStr);
            Console.WriteLine("********************调试中的debugNumber:语句：{0},{1}********************\n", DeadLineStr, String.Equals(Mindt, DeadLineStr));
            Console.WriteLine("********************调试中的debugNumber:语句：{0}********************\n\n", ReturnStr);
            if (String.Equals(Mindt,CheckOutStr))
            {
                CheckOutStr = "";
                like_equal[0] = "like '%";
            }
            if (String.Equals(Mindt, DeadLineStr))
            {
                DeadLineStr = "";
                like_equal[1] = "like '%";
            }
            if (String.Equals(Mindt, ReturnStr))
            {
                ReturnStr = "";
                like_equal[2] = "like '%";
            }
            Console.WriteLine("\n\n********************调试中的debugNumber:语句：{0}********************\n", CheckOutStr);
            Console.WriteLine("********************调试中的debugNumber:语句：{0}********************\n", DeadLineStr);
            Console.WriteLine("********************调试中的debugNumber:语句：{0}********************\n\n", ReturnStr);
            //Console.WriteLine("\n\n调试中的debugNumber:isbn号码：{0}\n\n",isbnStr);
            string BRselect_admin = String.Format("select * from BR where BRno like '%{0}%' and ISBNum like '%{1}%' and rid like '%{2}%' and CheckOutDate "+like_equal[0]+ "{3}'  and DeadLine " + like_equal[1] + "{4}' and ReturnDate " + like_equal[2] + "{5}' and fine like '%{6}%' "
                                                                , BRnoStr, ISBNStr, ridStr, CheckOutStr, DeadLineStr, ReturnStr, fineStr);
            Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", BRselect_admin);


            if (String.Equals(ifOverdue_combo.Text.Trim(), "是")){
                BRselect_admin += String.Format("and DeadLine <=  DATENAME(YEAR,GETDATE())+'/'+DATENAME(MONTH,GETDATE())+'/'+DATENAME(DAY,GETDATE())");
            }
            this.selectresults.DataSource = DataBase_Library.DBoperations.Query(BRselect_admin).Tables["ds"];
            sql_default = BRselect_admin;
            //Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", this.selectresults.Rows.Count);
            //Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", this.selectresults.Rows[0].Cells[3].Value.ToString().Trim());
            if (this.selectresults.Rows.Count > 1)
            {
                update_btn.Enabled = true;
                delete_btn.Enabled = true;
            }
            else
            {
                update_btn.Enabled = false;
                delete_btn.Enabled = false;
            }

        }

        private void ISBNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            BRno_text.Text = "";
            ISBNum_text.Text = "";
            rid_text.Text = "";
            CheckOutDate_text.Text = Mindt;
            DeadLine_text.Text = Mindt;
            ReturnDate_text.Text = Mindt;
            fine_text.Text = "0";
            
        }

        private void refresh_btn_Click(object sender, EventArgs e)
        {
            this.selectresults.DataSource = DataBase_Library.DBoperations.Query(sql_default).Tables["ds"];
        }

        private void insert_btn_Click(object sender, EventArgs e)
        {
            
                string BRno = BRno_text.Text.Trim();
                if (!String.IsNullOrEmpty(BRno))
                    {
                        MessageBox.Show("借阅信息序号默认每次自增1，不需要进行赋值！");
                    }
                string ISBNum = ISBNum_text.Text.Trim() ;
                string rid = rid_text.Text.Trim();
                string CheckOut = CheckOutDate_text.Value.ToShortDateString().ToString().Trim();
                string DeadLine = DeadLine_text.Value.ToShortDateString().ToString().Trim();
                string Return = ReturnDate_text.Value.ToShortDateString().ToString().Trim();
                string fine = fine_text.Text.Trim();
                string BRinsert = String.Format("insert into BR(ISBNum,rid,CheckOutDate,DeadLine,ReturnDate,fine) values ('{0}','{1}','{2}','{3}','{4}',{5})",
                                                      ISBNum, rid, CheckOut, DeadLine, Return, fine);
                this.selectresults.DataSource = DataBase_Library.DBoperations.ExecuteSql(BRinsert);
                return;
            
          
           
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            try
            {
                int index = selectresults.CurrentRow.Index;
                string BRnoStr = selectresults.Rows[index].Cells[0].Value.ToString().Trim();
                string deleteSql = String.Format("delete from BR where BRno = '{0}'", BRnoStr);
                string confirmMess = String.Format("确认删除{0}号借阅信息？", selectresults.Rows[index].Cells[0].Value.ToString().Trim());
                if (MessageBox.Show(confirmMess, "删除确认", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    if (DataBase_Library.DBoperations.ExecuteSql(deleteSql) > 0) //rows > 0
                    {
                        MessageBox.Show("删除成功");
                        selectresults.Rows.RemoveAt(index);
                    }
                    else
                    {
                        MessageBox.Show("删除失败！");
                    }
                }
            }
            catch (NullReferenceException NotRefE)
            {
                MessageBox.Show("未选择删除对象！");
                return;
            }
        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            try
            {
                int index = selectresults.CurrentRow.Index;
                BRUpdate bRUpdate = new BRUpdate(selectresults, index);
                bRUpdate.Owner = this;
                bRUpdate.Show(this);

            }
            catch (Exception NotRefE)
            {

                MessageBox.Show("未选择修改对象！");
                return;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void BR_admin_Load(object sender, EventArgs e)
        {
            this.Text = "管理员界面——借阅信息管理";
        }
    }
}
