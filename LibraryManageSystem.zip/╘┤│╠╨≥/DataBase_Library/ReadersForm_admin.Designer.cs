﻿namespace DataBase_Library
{
    partial class ReadersForm_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectconditionsgroupBox3 = new System.Windows.Forms.GroupBox();
            this.reset_btn = new System.Windows.Forms.Button();
            this.ravailable_text = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rsex_combo = new System.Windows.Forms.ComboBox();
            this.rid_text = new System.Windows.Forms.TextBox();
            this.rworkplace_text = new System.Windows.Forms.TextBox();
            this.ralready_text = new System.Windows.Forms.TextBox();
            this.rjob_text = new System.Windows.Forms.TextBox();
            this.rtel_text = new System.Windows.Forms.TextBox();
            this.rname_text = new System.Windows.Forms.TextBox();
            this.libcardnumlabel3 = new System.Windows.Forms.Label();
            this.departmentlabel3 = new System.Windows.Forms.Label();
            this.borrownumlabel3 = new System.Windows.Forms.Label();
            this.sexlabel3 = new System.Windows.Forms.Label();
            this.joblabel3 = new System.Windows.Forms.Label();
            this.phonenumlabel3 = new System.Windows.Forms.Label();
            this.namelabel3 = new System.Windows.Forms.Label();
            this.update_btn = new System.Windows.Forms.Button();
            this.selectresultsgroupBox3 = new System.Windows.Forms.GroupBox();
            this.refresh_btn = new System.Windows.Forms.Button();
            this.selectresults = new System.Windows.Forms.DataGridView();
            this.insert_btn = new System.Windows.Forms.Button();
            this.select_btn = new System.Windows.Forms.Button();
            this.delete_btn = new System.Windows.Forms.Button();
            this.BR = new System.Windows.Forms.Button();
            this.Books = new System.Windows.Forms.Button();
            this.Readers = new System.Windows.Forms.Button();
            this.selectconditionsgroupBox3.SuspendLayout();
            this.selectresultsgroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.selectresults)).BeginInit();
            this.SuspendLayout();
            // 
            // selectconditionsgroupBox3
            // 
            this.selectconditionsgroupBox3.Controls.Add(this.reset_btn);
            this.selectconditionsgroupBox3.Controls.Add(this.ravailable_text);
            this.selectconditionsgroupBox3.Controls.Add(this.label1);
            this.selectconditionsgroupBox3.Controls.Add(this.rsex_combo);
            this.selectconditionsgroupBox3.Controls.Add(this.rid_text);
            this.selectconditionsgroupBox3.Controls.Add(this.rworkplace_text);
            this.selectconditionsgroupBox3.Controls.Add(this.ralready_text);
            this.selectconditionsgroupBox3.Controls.Add(this.rjob_text);
            this.selectconditionsgroupBox3.Controls.Add(this.rtel_text);
            this.selectconditionsgroupBox3.Controls.Add(this.rname_text);
            this.selectconditionsgroupBox3.Controls.Add(this.libcardnumlabel3);
            this.selectconditionsgroupBox3.Controls.Add(this.departmentlabel3);
            this.selectconditionsgroupBox3.Controls.Add(this.borrownumlabel3);
            this.selectconditionsgroupBox3.Controls.Add(this.sexlabel3);
            this.selectconditionsgroupBox3.Controls.Add(this.joblabel3);
            this.selectconditionsgroupBox3.Controls.Add(this.phonenumlabel3);
            this.selectconditionsgroupBox3.Controls.Add(this.namelabel3);
            this.selectconditionsgroupBox3.Location = new System.Drawing.Point(64, 43);
            this.selectconditionsgroupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectconditionsgroupBox3.Name = "selectconditionsgroupBox3";
            this.selectconditionsgroupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectconditionsgroupBox3.Size = new System.Drawing.Size(822, 157);
            this.selectconditionsgroupBox3.TabIndex = 18;
            this.selectconditionsgroupBox3.TabStop = false;
            this.selectconditionsgroupBox3.Text = "查询条件";
            // 
            // reset_btn
            // 
            this.reset_btn.Location = new System.Drawing.Point(730, 124);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(75, 33);
            this.reset_btn.TabIndex = 27;
            this.reset_btn.Text = "复位";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // ravailable_text
            // 
            this.ravailable_text.Location = new System.Drawing.Point(687, 88);
            this.ravailable_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ravailable_text.Name = "ravailable_text";
            this.ravailable_text.Size = new System.Drawing.Size(118, 28);
            this.ravailable_text.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(609, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 15;
            this.label1.Text = "可借数量";
            // 
            // rsex_combo
            // 
            this.rsex_combo.FormattingEnabled = true;
            this.rsex_combo.Items.AddRange(new object[] {
            "男",
            "女"});
            this.rsex_combo.Location = new System.Drawing.Point(100, 88);
            this.rsex_combo.Name = "rsex_combo";
            this.rsex_combo.Size = new System.Drawing.Size(111, 26);
            this.rsex_combo.TabIndex = 14;
            // 
            // rid_text
            // 
            this.rid_text.Location = new System.Drawing.Point(493, 91);
            this.rid_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rid_text.Name = "rid_text";
            this.rid_text.Size = new System.Drawing.Size(112, 28);
            this.rid_text.TabIndex = 13;
            // 
            // rworkplace_text
            // 
            this.rworkplace_text.Location = new System.Drawing.Point(295, 91);
            this.rworkplace_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rworkplace_text.Name = "rworkplace_text";
            this.rworkplace_text.Size = new System.Drawing.Size(112, 28);
            this.rworkplace_text.TabIndex = 12;
            // 
            // ralready_text
            // 
            this.ralready_text.Location = new System.Drawing.Point(687, 29);
            this.ralready_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ralready_text.Name = "ralready_text";
            this.ralready_text.Size = new System.Drawing.Size(118, 28);
            this.ralready_text.TabIndex = 10;
            // 
            // rjob_text
            // 
            this.rjob_text.Location = new System.Drawing.Point(489, 30);
            this.rjob_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rjob_text.Name = "rjob_text";
            this.rjob_text.Size = new System.Drawing.Size(112, 28);
            this.rjob_text.TabIndex = 9;
            // 
            // rtel_text
            // 
            this.rtel_text.Location = new System.Drawing.Point(291, 30);
            this.rtel_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtel_text.Name = "rtel_text";
            this.rtel_text.Size = new System.Drawing.Size(112, 28);
            this.rtel_text.TabIndex = 8;
            // 
            // rname_text
            // 
            this.rname_text.Location = new System.Drawing.Point(100, 30);
            this.rname_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rname_text.Name = "rname_text";
            this.rname_text.Size = new System.Drawing.Size(112, 28);
            this.rname_text.TabIndex = 7;
            // 
            // libcardnumlabel3
            // 
            this.libcardnumlabel3.AutoSize = true;
            this.libcardnumlabel3.Location = new System.Drawing.Point(414, 95);
            this.libcardnumlabel3.Name = "libcardnumlabel3";
            this.libcardnumlabel3.Size = new System.Drawing.Size(80, 18);
            this.libcardnumlabel3.TabIndex = 6;
            this.libcardnumlabel3.Text = "借书证号";
            // 
            // departmentlabel3
            // 
            this.departmentlabel3.AutoSize = true;
            this.departmentlabel3.Location = new System.Drawing.Point(219, 95);
            this.departmentlabel3.Name = "departmentlabel3";
            this.departmentlabel3.Size = new System.Drawing.Size(80, 18);
            this.departmentlabel3.TabIndex = 5;
            this.departmentlabel3.Text = "工作部门";
            // 
            // borrownumlabel3
            // 
            this.borrownumlabel3.AutoSize = true;
            this.borrownumlabel3.BackColor = System.Drawing.SystemColors.Control;
            this.borrownumlabel3.Location = new System.Drawing.Point(609, 34);
            this.borrownumlabel3.Name = "borrownumlabel3";
            this.borrownumlabel3.Size = new System.Drawing.Size(80, 18);
            this.borrownumlabel3.TabIndex = 4;
            this.borrownumlabel3.Text = "已借数量";
            // 
            // sexlabel3
            // 
            this.sexlabel3.AutoSize = true;
            this.sexlabel3.Location = new System.Drawing.Point(30, 91);
            this.sexlabel3.Name = "sexlabel3";
            this.sexlabel3.Size = new System.Drawing.Size(44, 18);
            this.sexlabel3.TabIndex = 3;
            this.sexlabel3.Text = "性别";
            // 
            // joblabel3
            // 
            this.joblabel3.AutoSize = true;
            this.joblabel3.Location = new System.Drawing.Point(441, 34);
            this.joblabel3.Name = "joblabel3";
            this.joblabel3.Size = new System.Drawing.Size(44, 18);
            this.joblabel3.TabIndex = 2;
            this.joblabel3.Text = "职称";
            // 
            // phonenumlabel3
            // 
            this.phonenumlabel3.AutoSize = true;
            this.phonenumlabel3.Location = new System.Drawing.Point(219, 34);
            this.phonenumlabel3.Name = "phonenumlabel3";
            this.phonenumlabel3.Size = new System.Drawing.Size(80, 18);
            this.phonenumlabel3.TabIndex = 1;
            this.phonenumlabel3.Text = "联系电话";
            // 
            // namelabel3
            // 
            this.namelabel3.AutoSize = true;
            this.namelabel3.Location = new System.Drawing.Point(30, 30);
            this.namelabel3.Name = "namelabel3";
            this.namelabel3.Size = new System.Drawing.Size(44, 18);
            this.namelabel3.TabIndex = 0;
            this.namelabel3.Text = "姓名";
            // 
            // update_btn
            // 
            this.update_btn.Location = new System.Drawing.Point(727, 584);
            this.update_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(84, 28);
            this.update_btn.TabIndex = 22;
            this.update_btn.Text = "修改";
            this.update_btn.UseVisualStyleBackColor = true;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // selectresultsgroupBox3
            // 
            this.selectresultsgroupBox3.Controls.Add(this.refresh_btn);
            this.selectresultsgroupBox3.Controls.Add(this.selectresults);
            this.selectresultsgroupBox3.Location = new System.Drawing.Point(64, 242);
            this.selectresultsgroupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresultsgroupBox3.Name = "selectresultsgroupBox3";
            this.selectresultsgroupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresultsgroupBox3.Size = new System.Drawing.Size(811, 336);
            this.selectresultsgroupBox3.TabIndex = 19;
            this.selectresultsgroupBox3.TabStop = false;
            this.selectresultsgroupBox3.Text = "查询结果";
            // 
            // refresh_btn
            // 
            this.refresh_btn.Location = new System.Drawing.Point(736, 0);
            this.refresh_btn.Name = "refresh_btn";
            this.refresh_btn.Size = new System.Drawing.Size(75, 32);
            this.refresh_btn.TabIndex = 28;
            this.refresh_btn.Text = "刷新";
            this.refresh_btn.UseVisualStyleBackColor = true;
            this.refresh_btn.Click += new System.EventHandler(this.refresh_btn_Click);
            // 
            // selectresults
            // 
            this.selectresults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.selectresults.Location = new System.Drawing.Point(13, 28);
            this.selectresults.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresults.Name = "selectresults";
            this.selectresults.RowHeadersWidth = 51;
            this.selectresults.RowTemplate.Height = 27;
            this.selectresults.Size = new System.Drawing.Size(798, 300);
            this.selectresults.TabIndex = 0;
            this.selectresults.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.selectresultsdataGridView3_CellContentClick);
            // 
            // insert_btn
            // 
            this.insert_btn.Location = new System.Drawing.Point(98, 585);
            this.insert_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.insert_btn.Name = "insert_btn";
            this.insert_btn.Size = new System.Drawing.Size(84, 28);
            this.insert_btn.TabIndex = 20;
            this.insert_btn.Text = "新增";
            this.insert_btn.UseVisualStyleBackColor = true;
            this.insert_btn.Click += new System.EventHandler(this.insert_btn_Click);
            // 
            // select_btn
            // 
            this.select_btn.Location = new System.Drawing.Point(429, 207);
            this.select_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.select_btn.Name = "select_btn";
            this.select_btn.Size = new System.Drawing.Size(84, 28);
            this.select_btn.TabIndex = 26;
            this.select_btn.Text = "查询";
            this.select_btn.UseVisualStyleBackColor = true;
            this.select_btn.Click += new System.EventHandler(this.select_btn_Click);
            // 
            // delete_btn
            // 
            this.delete_btn.Location = new System.Drawing.Point(429, 584);
            this.delete_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(84, 28);
            this.delete_btn.TabIndex = 21;
            this.delete_btn.Text = "删除";
            this.delete_btn.UseVisualStyleBackColor = true;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // BR
            // 
            this.BR.Location = new System.Drawing.Point(249, 12);
            this.BR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BR.Name = "BR";
            this.BR.Size = new System.Drawing.Size(136, 29);
            this.BR.TabIndex = 29;
            this.BR.Text = "借阅图书信息";
            this.BR.UseVisualStyleBackColor = true;
            this.BR.Click += new System.EventHandler(this.BR_Click);
            // 
            // Books
            // 
            this.Books.Location = new System.Drawing.Point(159, 13);
            this.Books.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Books.Name = "Books";
            this.Books.Size = new System.Drawing.Size(98, 28);
            this.Books.TabIndex = 28;
            this.Books.Text = "图书信息";
            this.Books.UseVisualStyleBackColor = true;
            this.Books.Click += new System.EventHandler(this.Books_Click);
            // 
            // Readers
            // 
            this.Readers.Location = new System.Drawing.Point(64, 13);
            this.Readers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Readers.Name = "Readers";
            this.Readers.Size = new System.Drawing.Size(101, 28);
            this.Readers.TabIndex = 27;
            this.Readers.Text = "读者信息";
            this.Readers.UseVisualStyleBackColor = true;
            this.Readers.Click += new System.EventHandler(this.Readers_Click);
            // 
            // ReadersForm_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 620);
            this.Controls.Add(this.BR);
            this.Controls.Add(this.Books);
            this.Controls.Add(this.Readers);
            this.Controls.Add(this.selectconditionsgroupBox3);
            this.Controls.Add(this.update_btn);
            this.Controls.Add(this.selectresultsgroupBox3);
            this.Controls.Add(this.insert_btn);
            this.Controls.Add(this.select_btn);
            this.Controls.Add(this.delete_btn);
            this.Name = "ReadersForm_admin";
            this.Text = "ReadersForm_admin";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ReadersForm_admin_FormClosing);
            this.Load += new System.EventHandler(this.ReadersForm_admin_Load);
            this.selectconditionsgroupBox3.ResumeLayout(false);
            this.selectconditionsgroupBox3.PerformLayout();
            this.selectresultsgroupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.selectresults)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox selectconditionsgroupBox3;
        private System.Windows.Forms.TextBox rid_text;
        private System.Windows.Forms.TextBox rworkplace_text;
        private System.Windows.Forms.TextBox ralready_text;
        private System.Windows.Forms.TextBox rjob_text;
        private System.Windows.Forms.TextBox rtel_text;
        private System.Windows.Forms.TextBox rname_text;
        private System.Windows.Forms.Label libcardnumlabel3;
        private System.Windows.Forms.Label departmentlabel3;
        private System.Windows.Forms.Label borrownumlabel3;
        private System.Windows.Forms.Label sexlabel3;
        private System.Windows.Forms.Label joblabel3;
        private System.Windows.Forms.Label phonenumlabel3;
        private System.Windows.Forms.Label namelabel3;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.GroupBox selectresultsgroupBox3;
        private System.Windows.Forms.DataGridView selectresults;
        private System.Windows.Forms.Button insert_btn;
        private System.Windows.Forms.Button select_btn;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.ComboBox rsex_combo;
        private System.Windows.Forms.TextBox ravailable_text;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.Button refresh_btn;
        private System.Windows.Forms.Button BR;
        private System.Windows.Forms.Button Books;
        private System.Windows.Forms.Button Readers;
    }
}