﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class ReaderUpdate_admin : Form
    {
        public string[] dateBefore = new string[8];
        public ReaderUpdate_admin(DataGridView ReaderInfo, int index)
        {
            InitializeComponent();
            this.OverDueInfoData.Visible = false;
            string ridUstr = ReaderInfo.Rows[index].Cells[0].Value.ToString().Trim();
            update_group.Text = "修改读书卡号为" + ridUstr + "的信息";

            for (int i = 0; i < 8; i++)
            {
                dateBefore[i] = ReaderInfo.Rows[index].Cells[i].Value.ToString().Trim();
            }
            rid_text.Text = dateBefore[0];
            rname_text.Text = dateBefore[1];
            rsex_combo.Text = dateBefore[2];
            rjob_text.Text = dateBefore[3];
            ravailable_text.Text = dateBefore[4];
            ralready_text.Text = dateBefore[5];
            rworkplace_text.Text = dateBefore[6];
            rtel_text.Text = dateBefore[7];
        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            rid_text.Text = "";
            rname_text.Text = "";
            rsex_combo.Text = "";
            rjob_text.Text = "";
            ravailable_text.Text = "0";
            ralready_text.Text = "0";
            rworkplace_text.Text = "";
            rtel_text.Text = "";
        }

        private void update_confirm_Click(object sender, EventArgs e)
        {
            int update_flag = 0;
            string updateInfo = "";

            string ridStr = rid_text.Text.Trim();
            if (!String.Equals(ridStr, dateBefore[0]))
            {
                updateInfo += "修改读书卡号为" + ridStr + ",\n";
                update_flag++;
            }
            string rnameStr = rname_text.Text.Trim();
            if (!String.Equals(rnameStr, dateBefore[1]))
            {
                updateInfo += "修改姓名为" + rnameStr + ",\n";
                update_flag++;
            }
            string rsexStr = rsex_combo.Text.Trim();
            if (!String.Equals(rsexStr, dateBefore[2]))
            {
                updateInfo += "修改性别为" + rsexStr + ",\n";
                update_flag++;
            }
            string rjobStr = rjob_text.Text.Trim();
            if (!String.Equals(rjobStr, dateBefore[3]))
            {
                updateInfo += "修改工作职称为" + rjobStr + ",\n";
                update_flag++;
            }
            string ravlblStr = ravailable_text.Text.Trim();
            if (!String.Equals(ravlblStr, dateBefore[4]))
            {
                updateInfo += "修改可借数量为" + ravlblStr + ",\n";
                update_flag++;
            }
            string ralrdyStr = ralready_text.Text.Trim();
            if (!String.Equals(ralrdyStr, dateBefore[5]))
            {
                updateInfo += "修改已借数量为" + ralrdyStr + ",\n";
                update_flag++;
            }
            string rworkplaceStr = rworkplace_text.Text.Trim();
            if (!String.Equals(rworkplaceStr, dateBefore[6]))
            {
                updateInfo += "修改工作地点为" + rworkplaceStr + ",\n";
                update_flag++;
            }
            string rtelStr = rtel_text.Text.Trim();
            if (!String.Equals(rtelStr, dateBefore[7]))
            {
                updateInfo += "修改电话为" + rtelStr + ",\n";
                update_flag++;
            }
            if (update_flag == 0)
            {
                MessageBox.Show("未作出任何修改！", "重新修改");
                return;
            }
            string updateSql = String.Format("update Readers set rid = '{0}' , rname = '{1}' , rsex = '{2}', rjob = '{3}'  , ravailable = {4} , ralready = {5},rworkplace = '{6}' , rtel = '{7} 'where rid = '{8}'",
                                               ridStr, rnameStr, rsexStr, rjobStr, ravlblStr, ralrdyStr, rworkplaceStr, rtelStr, dateBefore[0]);
            if (MessageBox.Show(updateInfo, "确认修改？", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                if (DBoperations.ExecuteSql(updateSql) > 0) //rows > 0
                {
                    MessageBox.Show("修改成功");

                }
                else
                {
                    MessageBox.Show("修改失败！");
                }
            }
            else
            {
                return;
            }

            this.Dispose();

        }

        private void update_cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void OverDueInfo_btn_Click(object sender, EventArgs e)
        {
            this.OverDueInfoData.Visible = true;
            string OverDueSQL = String.Format("execute OverDueInfo  '{0}'",dateBefore[0].Trim());
            this.OverDueInfoData.DataSource = DBoperations.Query(OverDueSQL).Tables["ds"];

        }

        private void ReaderUpdate_admin_Load(object sender, EventArgs e)
        {
            this.Text = "管理员界面——读者信息修改";

        }
    }
}
