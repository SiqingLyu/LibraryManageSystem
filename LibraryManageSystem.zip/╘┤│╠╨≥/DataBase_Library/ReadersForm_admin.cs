﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataBase_Library;
namespace DataBase_Library
{
    public partial class ReadersForm_admin : Form
    {
        public string sql_default = "select * from Readers where rid = '-1'";
        public ReadersForm_admin()
        {
            InitializeComponent();
            rid_text.Text = "";
            rname_text.Text = "";
            rsex_combo.Text = "";
            rjob_text.Text = "";
            ravailable_text.Text = "0";
            ralready_text.Text = "0";
            rworkplace_text.Text = "";
            rtel_text.Text = "";
            update_btn.Enabled = false;
            delete_btn.Enabled = false;
        }

        private void booksbutton3_Click(object sender, EventArgs e)
        {   
          
        }

        private void ReadersForm_admin_FormClosing(object sender, FormClosingEventArgs e)
        {
            
                this.FormClosing -= ReadersForm_admin_FormClosing;
                Application.Exit();
         
        }

        private void selectresultsdataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void select_btn_Click(object sender, EventArgs e)
        {
            string ridStr = rid_text.Text.Trim();
            string rnameStr = rname_text.Text.Trim();
            string rsexStr = rsex_combo.Text.Trim();
            string rjobStr = rjob_text.Text.Trim();
            string ravlblStr = ravailable_text.Text.Trim();
            string ralrdyStr = ralready_text.Text.Trim();
            string rworkplaceStr = rworkplace_text.Text.Trim();
            string rtelStr = rtel_text.Text.Trim();
            if (String.IsNullOrEmpty(ravlblStr))
            {
                ravlblStr = "0";
            }
            if (String.IsNullOrEmpty(ralrdyStr))
            {
                ralrdyStr = "0";
            }
            //Console.WriteLine("\n\n调试中的debugNumber:isbn号码：{0}\n\n",isbnStr);
            string readerselect_admin = String.Format("select * from Readers where rid like '%{0}%' and rname like '%{1}%' and rsex like '%{2}%' and rjob like '%{3}%'  and ravailable >={4}  and ralready >= {5} and rworkplace like '%{6}%' and rtel like '%{7}%'"
                                                                , ridStr, rnameStr, rsexStr, rjobStr, ravlblStr, ralrdyStr, rworkplaceStr,rtelStr);
            //Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", bookselect_admin);
            this.selectresults.DataSource = DBoperations.Query(readerselect_admin).Tables["ds"];
            sql_default = readerselect_admin;
            Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", this.selectresults.Rows.Count);

            if (this.selectresults.Rows.Count > 1)
            {
                update_btn.Enabled = true;
                delete_btn.Enabled = true;
            }
            else
            {
                update_btn.Enabled = false;
                delete_btn.Enabled = false;
            }


        }

        private void insert_btn_Click(object sender, EventArgs e)
        {
            string ridStr = rid_text.Text.Trim();
            string rnameStr = rname_text.Text.Trim();
            string rsexStr = rsex_combo.Text.Trim();
            string rjobStr = rjob_text.Text.Trim();
            string ravlblStr = ravailable_text.Text.Trim();
            string ralrdyStr = ralready_text.Text.Trim();
            string rworkplaceStr = rworkplace_text.Text.Trim();
            string rtelStr = rtel_text.Text.Trim();
            string readerinsert = String.Format("insert into Books values ('{0}','{1}','{2}','{3}',{4},{5},'{6}','{7}')",
                                                 ridStr, rnameStr, rsexStr, rjobStr, ravlblStr, ralrdyStr, rworkplaceStr, rtelStr);
            this.selectresults.DataSource = DBoperations.ExecuteSql(readerinsert);
        }

        private void delete_btn_Click(object sender, EventArgs e)
        {
            try
            {


                int index = selectresults.CurrentRow.Index;
                string nameStr = selectresults.Rows[index].Cells[1].Value.ToString().Trim();
                string ridStr = selectresults.Rows[index].Cells[0].Value.ToString().Trim();
                string deleteSql = String.Format("delete from Readers where rid = '{0}'" +//here has a trigger in SQL for delete from LogInfo
                                                 " exec sp_droplogin '{1}'  exec sp_dropuser '{1}' ", ridStr, nameStr);
                string confirmMess = String.Format("确认删除读者{0}？", selectresults.Rows[index].Cells[1].Value.ToString().Trim());
                if (MessageBox.Show(confirmMess, "删除确认", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    if (DBoperations.ExecuteSql(deleteSql) > 0) //rows > 0
                    {
                        MessageBox.Show("删除成功");
                        selectresults.Rows.RemoveAt(index);
                    }
                    else
                    {
                        MessageBox.Show("删除失败！");
                    }
                }
            }
            catch (NullReferenceException NotRefE)
            {
                MessageBox.Show("未选择删除对象！");
                return;
            }

        }

        private void update_btn_Click(object sender, EventArgs e)
        {
             try
            {
                int index = selectresults.CurrentRow.Index;
                ReaderUpdate_admin readerUpdate = new ReaderUpdate_admin(selectresults, index);
                readerUpdate.Owner = this;
                readerUpdate.Show(this);

            }
            catch (Exception NotRefE)
            {

                MessageBox.Show("未选择修改对象！");
                return;
            }
        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            rid_text.Text = "";
            rname_text.Text = "";
            rsex_combo.Text = "";
            rjob_text.Text = "";
            ravailable_text.Text = "0";
            ralready_text.Text = "0";
            rworkplace_text.Text = "";
            rtel_text.Text = "";
        }

        private void refresh_btn_Click(object sender, EventArgs e)
        {
            this.selectresults.DataSource = DBoperations.Query(sql_default).Tables["ds"];
        }

        private void BR_Click(object sender, EventArgs e)
        {
            BR_admin bR_Admin = new BR_admin();
            bR_Admin.Show();
            this.Dispose();
        }

        private void Readers_Click(object sender, EventArgs e)
        {

        }

        private void Books_Click(object sender, EventArgs e)
        {
            BooksFrom_admin booksFrom_Admin = new BooksFrom_admin();
            booksFrom_Admin.Show();
            this.Dispose();
        }

        private void Clearall_btn_Click(object sender, EventArgs e)
        {
               
        }

        private void ReadersForm_admin_Load(object sender, EventArgs e)
        {
            this.Text = "管理员界面——读者信息管理";
        }
    }
}
