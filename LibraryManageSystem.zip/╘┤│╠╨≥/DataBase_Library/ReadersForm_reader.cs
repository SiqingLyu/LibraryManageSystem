﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class ReadersForm_reader : Form
    {
        public string sql_default =String.Format("select rid from Readers where rname = '{0}'",publicVar.currentUser.Trim());
        public ReadersForm_reader()
        {
            InitializeComponent();
            GetRid.Visible = false;
            //Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", bookselect_admin);
            this.GetRid.DataSource = DBoperations.Query(sql_default).Tables["ds"];
            publicVar.currentRid = GetRid.Rows[0].Cells[0].Value.ToString().Trim();
            Console.WriteLine("\n\n当前用户读书卡号：{0}\n\n", publicVar.currentRid);
            sql_default = "select * from Readers where rid = '-1'";
        }

        private void booksbutton8_Click(object sender, EventArgs e)
        {
            BooksFrom_reader childrenForm_BooksR = new BooksFrom_reader();
            childrenForm_BooksR.Show(this);
            this.Hide();
        }

        private void ReadersForm_reader_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("真的要退出程序吗？", "退出程序", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                this.FormClosing -= ReadersForm_reader_FormClosing;
                Application.Exit();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void BR_Click(object sender, EventArgs e)
        {
           
        }

        private void Books_Click(object sender, EventArgs e)
        {
           
        }

        private void Readers_Click(object sender, EventArgs e)
        {

        }

        private void select_btn_Click(object sender, EventArgs e)
        {
            string ridStr = rid_text.Text.Trim();
            string rnameStr = rname_text.Text.Trim();
            string rsexStr = rsex_combo.Text.Trim();
            string rjobStr = rjob_text.Text.Trim();
            string ravlblStr = ravailable_text.Text.Trim();
            string ralrdyStr = ralready_text.Text.Trim();
            string rworkplaceStr = rworkplace_text.Text.Trim();
            string rtelStr = rtel_text.Text.Trim();
            if (String.IsNullOrEmpty(ravlblStr))
            {
                ravlblStr = "0";
            }
            if (String.IsNullOrEmpty(ralrdyStr))
            {
                ralrdyStr = "0";
            }
            //Console.WriteLine("\n\n调试中的debugNumber:isbn号码：{0}\n\n",isbnStr);
            string readerselect_admin = String.Format("select * from Readers where rid like '%{0}%' and rname like '%{1}%' and rsex like '%{2}%' and rjob like '%{3}%'  and ravailable >={4}  and ralready >= {5} and rworkplace like '%{6}%' and rtel like '%{7}%'"
                                                                , ridStr, rnameStr, rsexStr, rjobStr, ravlblStr, ralrdyStr, rworkplaceStr, rtelStr);
            //Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", bookselect_admin);
            this.selectresults.DataSource = DBoperations.Query(readerselect_admin).Tables["ds"];
            sql_default = readerselect_admin;
            Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", this.selectresults.Rows.Count);

        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            rid_text.Text = "";
            rname_text.Text = "";
            rsex_combo.Text = "";
            rjob_text.Text = "";
            ravailable_text.Text = "0";
            ralready_text.Text = "0";
            rworkplace_text.Text = "";
            rtel_text.Text = "";
        }

        private void refresh_btn_Click(object sender, EventArgs e)
        {
            this.selectresults.DataSource = DBoperations.Query(sql_default).Tables["ds"];
        }

        private void updateMyInfo_btn_Click(object sender, EventArgs e)
        {
            try
            {
                ReaderUpdate_reader readerUpdate = new ReaderUpdate_reader();
                readerUpdate.Owner = this;
                readerUpdate.Show(this);

            }
            catch (Exception NotRefE)
            {

                MessageBox.Show("未选择修改对象！");
                return;
            }
        }

        private void Readers_Click_1(object sender, EventArgs e)
        {

        }

        private void Books_Click_1(object sender, EventArgs e)
        {
            BooksFrom_reader childrenForm_BooksR = new BooksFrom_reader();
            childrenForm_BooksR.Show();
            this.Dispose();
        }

        private void BR_Click_1(object sender, EventArgs e)
        {
            BR_reader bR_Reader = new BR_reader();
            bR_Reader.Show();
            this.Dispose();
        }

        private void ReadersForm_reader_Load(object sender, EventArgs e)
        {
            this.Text = "读者界面——读者信息查询";

        }
    }
}
