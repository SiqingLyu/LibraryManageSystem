﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class BookUpdate : Form
    {
        public string[] dateBefore = new string[7];
        public BookUpdate(DataGridView BookInfo,int index)
        {
            InitializeComponent();
            string isbnUstr = BookInfo.Rows[index].Cells[0].Value.ToString().Trim();
            update_group.Text = "修改书号为" + isbnUstr + "的信息";
            
            for(int i = 0; i < 7; i++)
            {
                dateBefore[i] = BookInfo.Rows[index].Cells[i].Value.ToString().Trim();
            }
            ISBN_text.Text = dateBefore[0];
            bookname_text.Text = dateBefore[1];
            press_text.Text = dateBefore[2];
            writer_text.Text = dateBefore[3];
            totalnum_text.Text = dateBefore[4];
            numAvailable_text.Text = dateBefore[5];
            ifAvailable_combo.Text = dateBefore[6];
        }

        private void selectconditionsgroupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            ISBN_text.Text = "";
            bookname_text.Text = "";
            press_text.Text = "";
            writer_text.Text = "";
            totalnum_text.Text = "0";
            numAvailable_text.Text = "0";
            ifAvailable_combo.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int update_flag = 0;
            string updateInfo = "";

            string isbnStr = ISBN_text.Text.Trim();
            if (!String.Equals(isbnStr, dateBefore[0]))
            {
                updateInfo += "修改ISBN为"+isbnStr+",\n";
                update_flag++;
            }
            string booknameStr = bookname_text.Text.Trim();
            if (!String.Equals(booknameStr, dateBefore[1]))
            {
                updateInfo += "修改书名为" + booknameStr + ",\n";
                update_flag++;
            }
            string pressStr = press_text.Text.Trim();
            if (!String.Equals(pressStr, dateBefore[2]))
            {
                updateInfo += "修改出版社为" + pressStr + ",\n";
                update_flag++;
            }
            string writerStr = writer_text.Text.Trim();
            if (!String.Equals(writerStr, dateBefore[3]))
            {
                updateInfo += "修改作者为" + writerStr + ",\n";
                update_flag++;
            }
            string totalnumStr = totalnum_text.Text.Trim();
            if (!String.Equals(totalnumStr, dateBefore[4]))
            {
                updateInfo += "修改总数量为" + totalnumStr + ",\n";
                update_flag++;
            }
            string avlblnumStr = numAvailable_text.Text.Trim();
            if (!String.Equals(avlblnumStr, dateBefore[5]))
            {
                updateInfo += "修改可借数量为" + avlblnumStr + ",\n";
                update_flag++;
            }
            string ifAvlblStr = ifAvailable_combo.Text.Trim();
            if (!String.Equals(ifAvlblStr, dateBefore[6]))
            {
                updateInfo += "修改是否可借为" + ifAvlblStr + ",\n";
                update_flag++;
            }

            if(update_flag == 0)
            {
                MessageBox.Show("未作出任何修改！", "重新修改");
                return;
            }
            string updateSql = String.Format("update Books set ISBNum = '{0}' , bname = '{1}' , bpress = '{2}', bwriter = '{3}'  , bnumAll = {4} , bnumAvailable = {5},bifAvailable = '{6}' where ISBNum = '{7}'",
                                              isbnStr, booknameStr, pressStr, writerStr, totalnumStr, avlblnumStr, ifAvlblStr, dateBefore[0]);
            if(MessageBox.Show(updateInfo,"确认修改？", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                if (DataBase_Library.DBoperations.ExecuteSql(updateSql) > 0) //rows > 0
                {
                    MessageBox.Show("修改成功");
                    
                }
                else
                {
                    MessageBox.Show("修改失败！");
                }
            }
            else
            {
                return;
            }

            this.Dispose();


        }

        private void update_cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void BookUpdate_Load(object sender, EventArgs e)
        {
            this.Text = "编辑图书信息";
        }
    }
}
