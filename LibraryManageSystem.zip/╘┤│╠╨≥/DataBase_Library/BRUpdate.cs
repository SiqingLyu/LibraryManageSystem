﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class BRUpdate : Form
    {
        public string Mindt = "1900/1/1";
        public string DefaultDate = DateTime.Now.ToShortDateString().ToString().Trim();
        public string[] dateBefore = new string[8];
        public BRUpdate(DataGridView BRInfo, int index)
        {
            InitializeComponent();
            string BRno = BRInfo.Rows[index].Cells[0].Value.ToString().Trim();
            update_group.Text = "修改序号号为" + BRno + "的借阅信息";

            for (int i = 0; i < 7; i++)
            {
                dateBefore[i] = BRInfo.Rows[index].Cells[i].Value.ToString().Trim();
            }
  
            ISBNum_text.Text = dateBefore[1];
            rid_text.Text = dateBefore[2];
            CheckOutDate_text.Text = dateBefore[3];
            DeadLine_text.Text = dateBefore[4];
            ReturnDate_text.Text = dateBefore[5];
            fine_text.Text = dateBefore[6];

        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            ISBNum_text.Text = dateBefore[1];
            rid_text.Text = dateBefore[2];
            CheckOutDate_text.Text = dateBefore[3];
            DeadLine_text.Text = dateBefore[4];
            ReturnDate_text.Text = dateBefore[5];
            fine_text.Text = dateBefore[6];
        }

        private void update_confirm_Click(object sender, EventArgs e)
        {
            int update_flag = 0;
            string updateInfo = "";
            string ISBNum = ISBNum_text.Text.Trim();
            if (!String.Equals(ISBNum, dateBefore[1]))
            {
                updateInfo += "修改ISBN书号为" + ISBNum + ",\n";
                update_flag++;
            }
            string rid = rid_text.Text.Trim();
            if (!String.Equals(rid, dateBefore[2]))
            {
                updateInfo += "修改读者卡号为" + rid + ",\n";
                update_flag++;
            }
            string CheckOut = CheckOutDate_text.Value.ToShortDateString().ToString().Trim();
            if (!String.Equals(CheckOut, dateBefore[3]))
            {
                updateInfo += "修改借出日期为" + CheckOut + ",\n";
                update_flag++;
            }
            string DeadLine = DeadLine_text.Value.ToShortDateString().ToString().Trim();
            if (!String.Equals(DeadLine, dateBefore[4]))
            {
                updateInfo += "修改截止日期为" + DeadLine + ",\n";
                update_flag++;
            }
            string Return = ReturnDate_text.Value.ToShortDateString().ToString().Trim();
            if (!String.Equals(Return, dateBefore[5]))
            {
                updateInfo += "修改截止日期为" + Return + ",\n";
                update_flag++;
            }
            string fine = fine_text.Text.Trim();
            if (!String.Equals(fine, dateBefore[6]))
            {
                updateInfo += "修改罚款为" + fine + ",\n";
                update_flag++;
            }

            if (update_flag == 0)
            {
                MessageBox.Show("未作出任何修改！", "重新修改");
                return;
            }
            string updateSql = String.Format("update BR set ISBNum = '{0}' , rid = '{1}' , CheckOutDate = '{2}', DeadLine = '{3}'  , ReturnDate = '{4}' , fine = {5} where BRno = '{6}'",
                                                ISBNum,rid,CheckOut,DeadLine,Return,fine, dateBefore[0]);

            DateTime dt1 = Convert.ToDateTime(DeadLine);
            DateTime dt2 = Convert.ToDateTime(Return);
            DateTime dt3 = Convert.ToDateTime(Mindt);
            if (DateTime.Compare(dt1, dt2) < 0)
            {
                TimeSpan ts1 = new TimeSpan(dt1.Ticks);
                TimeSpan ts2 = new TimeSpan(dt2.Ticks);
                TimeSpan ts3 = ts2.Subtract(ts1); //ts2-ts1
                int sumdays = int.Parse(ts3.TotalDays.ToString()); //得到相差天数
                if (sumdays > 0) //确认是否超时
                {
                    double fine_topay = (sumdays) * 0.2;
                    MessageBox.Show(String.Format("本条记录借书超时,将修改罚款为人民币 {0} 元", fine_topay.ToString().Trim()));
                    updateSql += String.Format("\nupdate BR set fine = {0} where BRno = '{1}'hu", fine_topay.ToString().Trim(),dateBefore[0]);
                }

            }

            if (MessageBox.Show(updateInfo, "确认修改？", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                if (DBoperations.ExecuteSql(updateSql) > 0) //rows > 0
                {
                    MessageBox.Show("修改成功");

                }
                else
                {
                    MessageBox.Show("修改失败！");
                }
            }
            else
            {
                return;
            }

            this.Dispose();

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void update_cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void BRUpdate_Load(object sender, EventArgs e)
        {
            this.Text = "编辑借阅信息";
        }
    }
}
