﻿namespace DataBase_Library
{
    partial class BooksFrom_reader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ISBNlabel6 = new System.Windows.Forms.Label();
            this.reset_btn = new System.Windows.Forms.Button();
            this.booknamelabel6 = new System.Windows.Forms.Label();
            this.collectionnumlabel6 = new System.Windows.Forms.Label();
            this.yesnoborrowlabel6 = new System.Windows.Forms.Label();
            this.writerlabel6 = new System.Windows.Forms.Label();
            this.select_btn = new System.Windows.Forms.Button();
            this.refresh_btn = new System.Windows.Forms.Button();
            this.ifAvailable_combo = new System.Windows.Forms.ComboBox();
            this.BR = new System.Windows.Forms.Button();
            this.Books = new System.Windows.Forms.Button();
            this.Readers = new System.Windows.Forms.Button();
            this.selectresultsgroupBox6 = new System.Windows.Forms.GroupBox();
            this.selectresults = new System.Windows.Forms.DataGridView();
            this.totalnum_text = new System.Windows.Forms.TextBox();
            this.press_text = new System.Windows.Forms.TextBox();
            this.bookname_text = new System.Windows.Forms.TextBox();
            this.writer_text = new System.Windows.Forms.TextBox();
            this.ISBN_text = new System.Windows.Forms.TextBox();
            this.canborrownumlabel6 = new System.Windows.Forms.Label();
            this.selectconditionsgroupBox6 = new System.Windows.Forms.GroupBox();
            this.numAvailable_text = new System.Windows.Forms.TextBox();
            this.presslabel6 = new System.Windows.Forms.Label();
            this.borrow_btn = new System.Windows.Forms.Button();
            this.selectresultsgroupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.selectresults)).BeginInit();
            this.selectconditionsgroupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // ISBNlabel6
            // 
            this.ISBNlabel6.AutoSize = true;
            this.ISBNlabel6.Location = new System.Drawing.Point(37, 32);
            this.ISBNlabel6.Name = "ISBNlabel6";
            this.ISBNlabel6.Size = new System.Drawing.Size(80, 18);
            this.ISBNlabel6.TabIndex = 0;
            this.ISBNlabel6.Text = "ISBN书号";
            // 
            // reset_btn
            // 
            this.reset_btn.Location = new System.Drawing.Point(715, 86);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(75, 33);
            this.reset_btn.TabIndex = 18;
            this.reset_btn.Text = "复位";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // booknamelabel6
            // 
            this.booknamelabel6.AutoSize = true;
            this.booknamelabel6.Location = new System.Drawing.Point(73, 90);
            this.booknamelabel6.Name = "booknamelabel6";
            this.booknamelabel6.Size = new System.Drawing.Size(44, 18);
            this.booknamelabel6.TabIndex = 4;
            this.booknamelabel6.Text = "书名";
            // 
            // collectionnumlabel6
            // 
            this.collectionnumlabel6.AutoSize = true;
            this.collectionnumlabel6.Location = new System.Drawing.Point(626, 32);
            this.collectionnumlabel6.Name = "collectionnumlabel6";
            this.collectionnumlabel6.Size = new System.Drawing.Size(80, 18);
            this.collectionnumlabel6.TabIndex = 3;
            this.collectionnumlabel6.Text = "馆藏数量";
            // 
            // yesnoborrowlabel6
            // 
            this.yesnoborrowlabel6.AutoSize = true;
            this.yesnoborrowlabel6.Location = new System.Drawing.Point(424, 32);
            this.yesnoborrowlabel6.Name = "yesnoborrowlabel6";
            this.yesnoborrowlabel6.Size = new System.Drawing.Size(80, 18);
            this.yesnoborrowlabel6.TabIndex = 2;
            this.yesnoborrowlabel6.Text = "是否可借";
            // 
            // writerlabel6
            // 
            this.writerlabel6.AutoSize = true;
            this.writerlabel6.Location = new System.Drawing.Point(256, 32);
            this.writerlabel6.Name = "writerlabel6";
            this.writerlabel6.Size = new System.Drawing.Size(44, 18);
            this.writerlabel6.TabIndex = 1;
            this.writerlabel6.Text = "作者";
            // 
            // select_btn
            // 
            this.select_btn.Location = new System.Drawing.Point(418, 222);
            this.select_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.select_btn.Name = "select_btn";
            this.select_btn.Size = new System.Drawing.Size(84, 28);
            this.select_btn.TabIndex = 23;
            this.select_btn.Text = "查询";
            this.select_btn.UseVisualStyleBackColor = true;
            this.select_btn.Click += new System.EventHandler(this.select_btn_Click);
            // 
            // refresh_btn
            // 
            this.refresh_btn.Location = new System.Drawing.Point(731, 0);
            this.refresh_btn.Name = "refresh_btn";
            this.refresh_btn.Size = new System.Drawing.Size(85, 32);
            this.refresh_btn.TabIndex = 18;
            this.refresh_btn.Text = "刷新";
            this.refresh_btn.UseVisualStyleBackColor = true;
            this.refresh_btn.Click += new System.EventHandler(this.refresh_btn_Click);
            // 
            // ifAvailable_combo
            // 
            this.ifAvailable_combo.FormattingEnabled = true;
            this.ifAvailable_combo.Items.AddRange(new object[] {
            "是",
            "否"});
            this.ifAvailable_combo.Location = new System.Drawing.Point(506, 28);
            this.ifAvailable_combo.Name = "ifAvailable_combo";
            this.ifAvailable_combo.Size = new System.Drawing.Size(112, 26);
            this.ifAvailable_combo.TabIndex = 14;
            // 
            // BR
            // 
            this.BR.Location = new System.Drawing.Point(253, 12);
            this.BR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BR.Name = "BR";
            this.BR.Size = new System.Drawing.Size(186, 29);
            this.BR.TabIndex = 22;
            this.BR.Text = "我的借阅图书信息";
            this.BR.UseVisualStyleBackColor = true;
            this.BR.Click += new System.EventHandler(this.BR_Click_1);
            // 
            // Books
            // 
            this.Books.Location = new System.Drawing.Point(163, 12);
            this.Books.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Books.Name = "Books";
            this.Books.Size = new System.Drawing.Size(96, 28);
            this.Books.TabIndex = 21;
            this.Books.Text = "图书信息";
            this.Books.UseVisualStyleBackColor = true;
            this.Books.Click += new System.EventHandler(this.Books_Click_1);
            // 
            // Readers
            // 
            this.Readers.Location = new System.Drawing.Point(73, 13);
            this.Readers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Readers.Name = "Readers";
            this.Readers.Size = new System.Drawing.Size(95, 28);
            this.Readers.TabIndex = 20;
            this.Readers.Text = "读者信息";
            this.Readers.UseVisualStyleBackColor = true;
            this.Readers.Click += new System.EventHandler(this.Readers_Click);
            // 
            // selectresultsgroupBox6
            // 
            this.selectresultsgroupBox6.Controls.Add(this.refresh_btn);
            this.selectresultsgroupBox6.Controls.Add(this.selectresults);
            this.selectresultsgroupBox6.Location = new System.Drawing.Point(73, 258);
            this.selectresultsgroupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresultsgroupBox6.Name = "selectresultsgroupBox6";
            this.selectresultsgroupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresultsgroupBox6.Size = new System.Drawing.Size(824, 310);
            this.selectresultsgroupBox6.TabIndex = 19;
            this.selectresultsgroupBox6.TabStop = false;
            this.selectresultsgroupBox6.Text = "查询结果";
            // 
            // selectresults
            // 
            this.selectresults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.selectresults.Location = new System.Drawing.Point(7, 29);
            this.selectresults.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresults.Name = "selectresults";
            this.selectresults.RowHeadersWidth = 51;
            this.selectresults.RowTemplate.Height = 27;
            this.selectresults.Size = new System.Drawing.Size(810, 274);
            this.selectresults.TabIndex = 0;
            // 
            // totalnum_text
            // 
            this.totalnum_text.Location = new System.Drawing.Point(704, 26);
            this.totalnum_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.totalnum_text.Name = "totalnum_text";
            this.totalnum_text.Size = new System.Drawing.Size(112, 28);
            this.totalnum_text.TabIndex = 12;
            // 
            // press_text
            // 
            this.press_text.Location = new System.Drawing.Point(306, 86);
            this.press_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.press_text.Name = "press_text";
            this.press_text.Size = new System.Drawing.Size(112, 28);
            this.press_text.TabIndex = 10;
            // 
            // bookname_text
            // 
            this.bookname_text.Location = new System.Drawing.Point(122, 86);
            this.bookname_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bookname_text.Name = "bookname_text";
            this.bookname_text.Size = new System.Drawing.Size(112, 28);
            this.bookname_text.TabIndex = 9;
            // 
            // writer_text
            // 
            this.writer_text.Location = new System.Drawing.Point(306, 26);
            this.writer_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.writer_text.Name = "writer_text";
            this.writer_text.Size = new System.Drawing.Size(112, 28);
            this.writer_text.TabIndex = 8;
            // 
            // ISBN_text
            // 
            this.ISBN_text.Location = new System.Drawing.Point(122, 26);
            this.ISBN_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ISBN_text.Name = "ISBN_text";
            this.ISBN_text.Size = new System.Drawing.Size(112, 28);
            this.ISBN_text.TabIndex = 7;
            // 
            // canborrownumlabel6
            // 
            this.canborrownumlabel6.AutoSize = true;
            this.canborrownumlabel6.Location = new System.Drawing.Point(425, 90);
            this.canborrownumlabel6.Name = "canborrownumlabel6";
            this.canborrownumlabel6.Size = new System.Drawing.Size(80, 18);
            this.canborrownumlabel6.TabIndex = 6;
            this.canborrownumlabel6.Text = "可借数量";
            // 
            // selectconditionsgroupBox6
            // 
            this.selectconditionsgroupBox6.Controls.Add(this.reset_btn);
            this.selectconditionsgroupBox6.Controls.Add(this.ifAvailable_combo);
            this.selectconditionsgroupBox6.Controls.Add(this.numAvailable_text);
            this.selectconditionsgroupBox6.Controls.Add(this.totalnum_text);
            this.selectconditionsgroupBox6.Controls.Add(this.press_text);
            this.selectconditionsgroupBox6.Controls.Add(this.bookname_text);
            this.selectconditionsgroupBox6.Controls.Add(this.writer_text);
            this.selectconditionsgroupBox6.Controls.Add(this.ISBN_text);
            this.selectconditionsgroupBox6.Controls.Add(this.canborrownumlabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.presslabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.booknamelabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.collectionnumlabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.yesnoborrowlabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.writerlabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.ISBNlabel6);
            this.selectconditionsgroupBox6.Location = new System.Drawing.Point(73, 74);
            this.selectconditionsgroupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectconditionsgroupBox6.Name = "selectconditionsgroupBox6";
            this.selectconditionsgroupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectconditionsgroupBox6.Size = new System.Drawing.Size(824, 140);
            this.selectconditionsgroupBox6.TabIndex = 18;
            this.selectconditionsgroupBox6.TabStop = false;
            this.selectconditionsgroupBox6.Text = "查询条件";
            // 
            // numAvailable_text
            // 
            this.numAvailable_text.Location = new System.Drawing.Point(506, 86);
            this.numAvailable_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numAvailable_text.Name = "numAvailable_text";
            this.numAvailable_text.Size = new System.Drawing.Size(112, 28);
            this.numAvailable_text.TabIndex = 13;
            // 
            // presslabel6
            // 
            this.presslabel6.AutoSize = true;
            this.presslabel6.Location = new System.Drawing.Point(241, 90);
            this.presslabel6.Name = "presslabel6";
            this.presslabel6.Size = new System.Drawing.Size(62, 18);
            this.presslabel6.TabIndex = 5;
            this.presslabel6.Text = "出版社";
            // 
            // borrow_btn
            // 
            this.borrow_btn.Location = new System.Drawing.Point(414, 575);
            this.borrow_btn.Name = "borrow_btn";
            this.borrow_btn.Size = new System.Drawing.Size(77, 35);
            this.borrow_btn.TabIndex = 19;
            this.borrow_btn.Text = "借书";
            this.borrow_btn.UseVisualStyleBackColor = true;
            this.borrow_btn.Click += new System.EventHandler(this.borrow_btn_Click);
            // 
            // BooksFrom_reader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 615);
            this.Controls.Add(this.borrow_btn);
            this.Controls.Add(this.select_btn);
            this.Controls.Add(this.BR);
            this.Controls.Add(this.Books);
            this.Controls.Add(this.Readers);
            this.Controls.Add(this.selectresultsgroupBox6);
            this.Controls.Add(this.selectconditionsgroupBox6);
            this.Name = "BooksFrom_reader";
            this.Text = "BooksFrom_reader";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BooksFrom_reader_FormClosing);
            this.Load += new System.EventHandler(this.BooksFrom_reader_Load);
            this.selectresultsgroupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.selectresults)).EndInit();
            this.selectconditionsgroupBox6.ResumeLayout(false);
            this.selectconditionsgroupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label ISBNlabel6;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.Label booknamelabel6;
        private System.Windows.Forms.Label collectionnumlabel6;
        private System.Windows.Forms.Label yesnoborrowlabel6;
        private System.Windows.Forms.Label writerlabel6;
        private System.Windows.Forms.Button select_btn;
        private System.Windows.Forms.Button refresh_btn;
        private System.Windows.Forms.ComboBox ifAvailable_combo;
        private System.Windows.Forms.Button BR;
        private System.Windows.Forms.Button Books;
        private System.Windows.Forms.Button Readers;
        private System.Windows.Forms.GroupBox selectresultsgroupBox6;
        private System.Windows.Forms.DataGridView selectresults;
        private System.Windows.Forms.TextBox totalnum_text;
        private System.Windows.Forms.TextBox press_text;
        private System.Windows.Forms.TextBox bookname_text;
        private System.Windows.Forms.TextBox writer_text;
        private System.Windows.Forms.TextBox ISBN_text;
        private System.Windows.Forms.Label canborrownumlabel6;
        private System.Windows.Forms.GroupBox selectconditionsgroupBox6;
        private System.Windows.Forms.TextBox numAvailable_text;
        private System.Windows.Forms.Label presslabel6;
        private System.Windows.Forms.Button borrow_btn;
    }
}