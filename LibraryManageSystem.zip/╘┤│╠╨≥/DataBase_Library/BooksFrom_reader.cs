﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class BooksFrom_reader : Form
    {
        public string sql_default = "select * from Books where ISBNum = '-1'";
        public BooksFrom_reader()
        {
            InitializeComponent();
        }

        private void BooksFrom_reader_Load(object sender, EventArgs e)
        {
            this.Text = "读者界面——图书查询";
        }

        private void readersbutton4_Click(object sender, EventArgs e)
        {
            ReadersForm_reader childrenForm_ReadersR = new ReadersForm_reader();
            childrenForm_ReadersR.Show();
            this.Dispose();
        }

        private void BooksFrom_reader_FormClosing(object sender, FormClosingEventArgs e)
        {
           
            if (MessageBox.Show("真的要退出程序吗？", "退出程序", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                this.FormClosing -= BooksFrom_reader_FormClosing;
                Application.Exit();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void BR_Click(object sender, EventArgs e)
        {
            BR_reader bR_Reader = new BR_reader();
            bR_Reader.Show();
            this.Dispose();
        }

        private void Books_Click(object sender, EventArgs e)
        {
           
        }

        private void selectbutton4_Click(object sender, EventArgs e)
        {
          
        }

        private void borrow_btn_Click(object sender, EventArgs e)
        {

            try
            {
                int index = selectresults.CurrentRow.Index;
                string ifAvailable = selectresults.Rows[index].Cells[6].Value.ToString().Trim();
                Console.WriteLine("是否可借信息：{0}",ifAvailable);
                string numAvailable = selectresults.Rows[index].Cells[5].Value.ToString().Trim();



                if (numAvailable != "0" && ifAvailable == "是")
                {
                    string isbnStr = selectresults.Rows[index].Cells[0].Value.ToString().Trim();
                    string ridStr = publicVar.currentRid;
                    if (String.IsNullOrEmpty(ridStr))
                    {
                        MessageBox.Show("查不到您的读书卡号，请先完善您的信息");
                    }
                    string CheckOut = DateTime.Now.ToShortDateString().ToString().Trim();
                    string DeadLine = DateTime.Now.AddMonths(1).ToShortDateString().ToString().Trim();
                    string fine = "0";
                    string ReturnStr = "1900/1/1";
                    string bookborrow = String.Format("insert into BR(ISBNum,rid,CheckOutDate,DeadLine,ReturnDate,fine) values ('{0}','{1}','{2}','{3}','{4}',{5})",
                                                         isbnStr, ridStr, CheckOut, DeadLine, ReturnStr, fine);
                    bookborrow += String.Format("\nupdate Readers set ralready = ralready+1,ravailable = ravailable -1 where rid = '{0}'",publicVar.currentRid.Trim());
                    bookborrow += String.Format("\nupdate Books set bnumAvailable = bnumAvailable - 1 where ISBNum = '{0}' ",isbnStr);
                    Console.WriteLine("SQL语句信息：{0}",bookborrow);
                    try
                    {
                        this.selectresults.DataSource = DBoperations.ExecuteSql(bookborrow);
                        MessageBox.Show("借阅成功，一个月内归还");
                    }
                    catch
                    {
                        MessageBox.Show("借阅失败");
                    }
                }
                else
                {
                    MessageBox.Show("借阅失败，书本不足，无法借阅");
                }
               
                //Borrow borrow = new Borrow(selectresults, index);
                //borrow.Owner = this;
                // borrow.Show(this);

            }
            catch (Exception NotRefE)
            {

                MessageBox.Show("未选择借阅书籍！");
                return;
            }
           
           
        }

        private void select_btn_Click(object sender, EventArgs e)
        {
            string isbnStr = ISBN_text.Text.Trim();
            string booknameStr = bookname_text.Text.Trim();
            string pressStr = press_text.Text.Trim();
            string writerStr = writer_text.Text.Trim();
            string totalnumStr = totalnum_text.Text.Trim();
            string avlblnumStr = numAvailable_text.Text.Trim();
            string ifAvlblStr = ifAvailable_combo.Text.Trim();
            if (String.IsNullOrEmpty(totalnumStr))
            {
                totalnumStr = "0";
            }
            if (String.IsNullOrEmpty(avlblnumStr))
            {
                avlblnumStr = "0";
            }
            //Console.WriteLine("\n\n调试中的debugNumber:isbn号码：{0}\n\n",isbnStr);
            string bookselect_admin = String.Format("select * from Books where ISBNum like '%{0}%' and bname like '%{1}%' and bwriter like '%{2}%' and bifAvailable like '%{3}%'  and bpress like '%{4}%'  and bnumAll >= {5} and bnumAvailable >= {6}"
                                                                , isbnStr, booknameStr, writerStr, ifAvlblStr, pressStr, totalnumStr, avlblnumStr);
            //Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", bookselect_admin);
            this.selectresults.DataSource = DBoperations.Query(bookselect_admin).Tables["ds"];
            sql_default = bookselect_admin;
            Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", this.selectresults.Rows.Count);

            if (this.selectresults.Rows.Count > 1)
            {
                borrow_btn.Enabled = true;
               
            }
            else
            {
                borrow_btn.Enabled = false;
               
            }


        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            ISBN_text.Text = "";
            bookname_text.Text = "";
            press_text.Text = "";
            writer_text.Text = "";
            totalnum_text.Text = "0";
            numAvailable_text.Text = "0";
            ifAvailable_combo.Text = "";
        }

        private void refresh_btn_Click(object sender, EventArgs e)
        {
            this.selectresults.DataSource = DBoperations.Query(sql_default).Tables["ds"];
        }

        private void Books_Click_1(object sender, EventArgs e)
        {

        }

        private void Readers_Click(object sender, EventArgs e)
        {
            ReadersForm_reader readersForm_Reader = new ReadersForm_reader();
            readersForm_Reader.Show();
            this.Dispose();
        }

        private void BR_Click_1(object sender, EventArgs e)
        {
            BR_reader bR_Reader = new BR_reader();
            bR_Reader.Show();
            this.Dispose();
        }

        private void return_btn_Click(object sender, EventArgs e)
        {
           
           
        }
    }
}
