﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBase_Library
{
    class publicVar
    {
        public enum Status { Reader, Admin, Vistor};
        public static Status currentStatu = Status.Vistor; 
        public static string currentUser = "";
        public static string currentPasswd = "";
        public static string currentRid = "";
        public static SqlConnection currentConnection = new SqlConnection();
        public static string adminCertify = "123456";

    }
}
