﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class signin : Form
    {
        string signinTran = "";
        public signin()
        {
            InitializeComponent();
            ReaderInfoGroup.Visible = false;
            AdminCertifyGroup.Visible = false;
            rsex_combo.Text = "男";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void signin_confirm_Click(object sender, EventArgs e)
        {
            string username = name.Text.Trim();
            string password = passwd.Text;
            if (String.IsNullOrEmpty(username) || String.IsNullOrEmpty(password))
            {
                MessageBox.Show("信息不完整！", "重新填写");
                return;
            }
            string AdminConnectionString = "server=localhost;database=Library;uid=tutu;pwd=123456";
            SqlConnection Adconn = new SqlConnection(AdminConnectionString);
            if (AdminCertifyGroup.Visible == true)
            {
                if (adminCertify_txt.Text.Trim() != publicVar.adminCertify)
                {
                    MessageBox.Show("管理员认证失败！");
                    return;
                }

            }
            string role = (id_box.Text == "admin") ? "Lbry_admin" : "Lbry_reader";
            signinTran = String.Format(@"
                                                    set xact_abort on
                                                    exec sp_addlogin '{0}', '{1}','Library'
                                                    exec sp_adduser '{2}','{3}'
                                                    exec sp_addrolemember '{4}','{5}'
                                                    insert into LogInfo(username,passwd,Logid)
                                                    values('{6}','{7}','{8}')
                                                    
                                                ",
                                                 username,password,username,username,role,username,username,password,id_box.Text );
            if(ReaderInfoGroup.Visible == true)
            {
                if (String.IsNullOrEmpty(rsex_combo.Text) || String.IsNullOrEmpty(Rid_text.Text))
                {
                    MessageBox.Show("信息不完整，请至少填写读书卡号和性别！");
                    return;
                }
                signinTran += String.Format("insert into Readers(rid,rname,rjob,rsex,rworkplace,rtel,ravailable,ralready) values('{0}','{1}','{2}','{3}','{4}','{5}',20,0)"
                                        , Rid_text.Text.Trim(), name.Text.Trim(), rjob_text.Text.Trim(), rsex_combo.Text.Trim(), rworkplace_text.Text.Trim(), rtel_text.Text.Trim());
                MessageBox.Show("欢迎注册图书馆账户，新用户默认可借20本书籍。");
                publicVar.currentRid = Rid_text.Text.Trim();

            }
           
            
            SqlCommand signinCmd = new SqlCommand(signinTran, Adconn);
            try
            {
                Adconn.Open();
                signinCmd.ExecuteNonQuery();
            }
            catch(SqlException Sqle)
            {
                MessageBox.Show(Sqle.Message, "Error");
                Adconn.Close();
                signinCmd.Dispose();
                return;
            }
            finally
            {
                signinCmd.Dispose();
            }
            MessageBox.Show("注册成功！");
            this.Dispose();
          


        }

        private void id_box_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.id_box.Text.Trim() == "reader")
            {
                ReaderInfoGroup.Visible = true;
            }
            else
            {
                ReaderInfoGroup.Visible = false;
            }
            if (this.id_box.Text.Trim() == "admin")
            {
                AdminCertifyGroup.Visible = true;
            }
            else
            {
                AdminCertifyGroup.Visible = false;
            }
        }

        private void signin_Load(object sender, EventArgs e)
        {
            this.Text = "注册";

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
