﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace DataBase_Library
{
    public partial class BooksFrom_admin : Form
    {
        public string sql_default = "select * from Books where ISBNum = '-1'";
  
        public BooksFrom_admin()
        {
            InitializeComponent();
            ISBN_text.Text = "";
            bookname_text.Text = "";
            press_text.Text = "";
            writer_text.Text = "";
            totalnum_text.Text = "0";
            numAvailable_text.Text = "0";
            ifAvailable_combo.Text = "";
            update_btn.Enabled = false;
            delete_btn.Enabled = false;
            
        }

        private void readersbutton6_Click(object sender, EventArgs e)
        {
            ReadersForm_admin childrenForm_Readers = new ReadersForm_admin();
            childrenForm_Readers.Show();
            this.Dispose();
        }

        private void deletebutton6_Click(object sender, EventArgs e)
        {
          
            try
            {


                int index = selectresults.CurrentRow.Index;
                string isbnDstr = selectresults.Rows[index].Cells[0].Value.ToString().Trim();
                string deleteSql = String.Format("delete from Books where ISBNum = '{0}'", isbnDstr);
                string confirmMess = String.Format("确认删除图书{0}", selectresults.Rows[index].Cells[1].Value.ToString().Trim());
                if (MessageBox.Show(confirmMess, "删除确认", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    if (DBoperations.ExecuteSql(deleteSql) > 0) //rows > 0
                    {
                        MessageBox.Show("删除成功");
                        selectresults.Rows.RemoveAt(index);
                    }
                    else
                    {
                        MessageBox.Show("删除失败！");
                    }
                }
            }
            catch (NullReferenceException NotRefE)
            {
                MessageBox.Show("未选择删除对象！");
                return;
            }
          
        }

        private void newaddbutton6_Click(object sender, EventArgs e)
        {
            string isbnStr = ISBN_text.Text.Trim();
            string booknameStr = bookname_text.Text.Trim();
            string pressStr = press_text.Text.Trim();
            string writerStr = writer_text.Text.Trim();
            string totalnumStr = totalnum_text.Text.Trim();
            string avlblnumStr = numAvailable_text.Text.Trim();
            string ifAvlblStr = ifAvailable_combo.Text.Trim();
            string bookinsert = String.Format("insert into Books values ('{0}','{1}','{2}','{3}',{4},{5},'{6}')",
                                                 isbnStr, booknameStr, pressStr, writerStr, totalnumStr, avlblnumStr, ifAvlblStr);
            this.selectresults.DataSource = DBoperations.ExecuteSql(bookinsert);


        }

        private void select_btn_Click(object sender, EventArgs e)
        {
            string isbnStr = ISBN_text.Text.Trim();
            string booknameStr = bookname_text.Text.Trim();
            string pressStr = press_text.Text.Trim();
            string writerStr = writer_text.Text.Trim();
            string totalnumStr = totalnum_text.Text.Trim();
            string avlblnumStr = numAvailable_text.Text.Trim();
            string ifAvlblStr = ifAvailable_combo.Text.Trim();
            if (String.IsNullOrEmpty(totalnumStr))
            {
                totalnumStr = "0";
            }
            if (String.IsNullOrEmpty(avlblnumStr))
            {
                avlblnumStr = "0";
            }
            //Console.WriteLine("\n\n调试中的debugNumber:isbn号码：{0}\n\n",isbnStr);
            string bookselect_admin = String.Format("select * from Books where ISBNum like '%{0}%' and bname like '%{1}%' and bwriter like '%{2}%' and bifAvailable like '%{3}%'  and bpress like '%{4}%'  and bnumAll >= {5} and bnumAvailable >= {6}"
                                                                , isbnStr, booknameStr, writerStr, ifAvlblStr, pressStr, totalnumStr, avlblnumStr);
            //Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", bookselect_admin);
            this.selectresults.DataSource = DBoperations.Query(bookselect_admin).Tables["ds"];
            sql_default = bookselect_admin;
             Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", this.selectresults.Rows.Count);
            
            if (this.selectresults.Rows.Count > 1 )
            {
                update_btn.Enabled = true;
                delete_btn.Enabled = true;
            }
            else
            {
                update_btn.Enabled = false;
                delete_btn.Enabled = false;
            }
            
                
            
        }

        private void selectresults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ISBN_text.Text = "";
            bookname_text.Text = "";
            press_text.Text = "";
            writer_text.Text = "";
            totalnum_text.Text = "0";
            numAvailable_text.Text = "0";
            ifAvailable_combo.Text = "";
        }

        private void update_btn_Click(object sender, EventArgs e)
        {
            
            try
            {
                int index = selectresults.CurrentRow.Index;
                BookUpdate bookUpdate = new BookUpdate(selectresults, index);
                bookUpdate.Owner = this;
                bookUpdate.Show(this);

            }
            catch (Exception NotRefE)
            {

                MessageBox.Show("未选择修改对象！");
                return;
            }
          

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.selectresults.DataSource = DBoperations.Query(sql_default).Tables["ds"];
        }

        private void BooksFrom_admin_FormClosing(object sender, FormClosingEventArgs e)
        {
          
                this.FormClosing -= BooksFrom_admin_FormClosing;
                Application.Exit();
             
        }

        private void BooksFrom_admin_Load(object sender, EventArgs e)
        {
            this.Text = "管理员界面——图书管理";
        }

        private void BR_Click(object sender, EventArgs e)
        {
            BR_admin bR_Admin = new BR_admin();
            bR_Admin.Show();
            this.Dispose();
        }

        private void Books_Click(object sender, EventArgs e)
        {
           
        }
    }
   






}

