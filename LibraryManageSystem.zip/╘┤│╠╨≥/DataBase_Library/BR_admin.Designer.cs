﻿namespace DataBase_Library
{
    partial class BR_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reset_btn = new System.Windows.Forms.Button();
            this.collectionnumlabel6 = new System.Windows.Forms.Label();
            this.yesnoborrowlabel6 = new System.Windows.Forms.Label();
            this.writerlabel6 = new System.Windows.Forms.Label();
            this.ISBNlabel6 = new System.Windows.Forms.Label();
            this.refresh_btn = new System.Windows.Forms.Button();
            this.selectresults = new System.Windows.Forms.DataGridView();
            this.select_btn = new System.Windows.Forms.Button();
            this.selectresultsgroupBox6 = new System.Windows.Forms.GroupBox();
            this.fine_text = new System.Windows.Forms.TextBox();
            this.ISBNum_text = new System.Windows.Forms.TextBox();
            this.BRno_text = new System.Windows.Forms.TextBox();
            this.insert_btn = new System.Windows.Forms.Button();
            this.delete_btn = new System.Windows.Forms.Button();
            this.selectconditionsgroupBox6 = new System.Windows.Forms.GroupBox();
            this.rid_text = new System.Windows.Forms.TextBox();
            this.ifOverdue_combo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CheckOutDate_text = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.ReturnDate_text = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.DeadLine_text = new System.Windows.Forms.DateTimePicker();
            this.presslabel6 = new System.Windows.Forms.Label();
            this.update_btn = new System.Windows.Forms.Button();
            this.BR = new System.Windows.Forms.Button();
            this.Books = new System.Windows.Forms.Button();
            this.Readers = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.selectresults)).BeginInit();
            this.selectresultsgroupBox6.SuspendLayout();
            this.selectconditionsgroupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // reset_btn
            // 
            this.reset_btn.Location = new System.Drawing.Point(778, 43);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(85, 33);
            this.reset_btn.TabIndex = 18;
            this.reset_btn.Text = "复位";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // collectionnumlabel6
            // 
            this.collectionnumlabel6.AutoSize = true;
            this.collectionnumlabel6.Location = new System.Drawing.Point(635, 13);
            this.collectionnumlabel6.Name = "collectionnumlabel6";
            this.collectionnumlabel6.Size = new System.Drawing.Size(80, 18);
            this.collectionnumlabel6.TabIndex = 3;
            this.collectionnumlabel6.Text = "截止日期";
            this.collectionnumlabel6.Click += new System.EventHandler(this.collectionnumlabel6_Click);
            // 
            // yesnoborrowlabel6
            // 
            this.yesnoborrowlabel6.AutoSize = true;
            this.yesnoborrowlabel6.Location = new System.Drawing.Point(37, 96);
            this.yesnoborrowlabel6.Name = "yesnoborrowlabel6";
            this.yesnoborrowlabel6.Size = new System.Drawing.Size(80, 18);
            this.yesnoborrowlabel6.TabIndex = 2;
            this.yesnoborrowlabel6.Text = "读者卡号";
            // 
            // writerlabel6
            // 
            this.writerlabel6.AutoSize = true;
            this.writerlabel6.Location = new System.Drawing.Point(238, 31);
            this.writerlabel6.Name = "writerlabel6";
            this.writerlabel6.Size = new System.Drawing.Size(62, 18);
            this.writerlabel6.TabIndex = 1;
            this.writerlabel6.Text = "ISBN号";
            // 
            // ISBNlabel6
            // 
            this.ISBNlabel6.AutoSize = true;
            this.ISBNlabel6.Location = new System.Drawing.Point(37, 32);
            this.ISBNlabel6.Name = "ISBNlabel6";
            this.ISBNlabel6.Size = new System.Drawing.Size(80, 18);
            this.ISBNlabel6.TabIndex = 0;
            this.ISBNlabel6.Text = "信息序号";
            // 
            // refresh_btn
            // 
            this.refresh_btn.Location = new System.Drawing.Point(731, 0);
            this.refresh_btn.Name = "refresh_btn";
            this.refresh_btn.Size = new System.Drawing.Size(85, 32);
            this.refresh_btn.TabIndex = 18;
            this.refresh_btn.Text = "刷新";
            this.refresh_btn.UseVisualStyleBackColor = true;
            this.refresh_btn.Click += new System.EventHandler(this.refresh_btn_Click);
            // 
            // selectresults
            // 
            this.selectresults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.selectresults.Location = new System.Drawing.Point(6, 28);
            this.selectresults.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresults.Name = "selectresults";
            this.selectresults.RowHeadersWidth = 51;
            this.selectresults.RowTemplate.Height = 27;
            this.selectresults.Size = new System.Drawing.Size(810, 274);
            this.selectresults.TabIndex = 0;
            // 
            // select_btn
            // 
            this.select_btn.Location = new System.Drawing.Point(390, 227);
            this.select_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.select_btn.Name = "select_btn";
            this.select_btn.Size = new System.Drawing.Size(84, 28);
            this.select_btn.TabIndex = 23;
            this.select_btn.Text = "查询";
            this.select_btn.UseVisualStyleBackColor = true;
            this.select_btn.Click += new System.EventHandler(this.select_btn_Click);
            // 
            // selectresultsgroupBox6
            // 
            this.selectresultsgroupBox6.Controls.Add(this.refresh_btn);
            this.selectresultsgroupBox6.Controls.Add(this.selectresults);
            this.selectresultsgroupBox6.Location = new System.Drawing.Point(45, 263);
            this.selectresultsgroupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresultsgroupBox6.Name = "selectresultsgroupBox6";
            this.selectresultsgroupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresultsgroupBox6.Size = new System.Drawing.Size(824, 310);
            this.selectresultsgroupBox6.TabIndex = 19;
            this.selectresultsgroupBox6.TabStop = false;
            this.selectresultsgroupBox6.Text = "查询结果";
            // 
            // fine_text
            // 
            this.fine_text.Location = new System.Drawing.Point(306, 86);
            this.fine_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fine_text.Name = "fine_text";
            this.fine_text.Size = new System.Drawing.Size(112, 28);
            this.fine_text.TabIndex = 10;
            // 
            // ISBNum_text
            // 
            this.ISBNum_text.Location = new System.Drawing.Point(307, 26);
            this.ISBNum_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ISBNum_text.Name = "ISBNum_text";
            this.ISBNum_text.Size = new System.Drawing.Size(112, 28);
            this.ISBNum_text.TabIndex = 8;
            this.ISBNum_text.TextChanged += new System.EventHandler(this.ISBNum_TextChanged);
            // 
            // BRno_text
            // 
            this.BRno_text.Location = new System.Drawing.Point(122, 26);
            this.BRno_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BRno_text.Name = "BRno_text";
            this.BRno_text.Size = new System.Drawing.Size(112, 28);
            this.BRno_text.TabIndex = 7;
            // 
            // insert_btn
            // 
            this.insert_btn.Location = new System.Drawing.Point(75, 579);
            this.insert_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.insert_btn.Name = "insert_btn";
            this.insert_btn.Size = new System.Drawing.Size(84, 28);
            this.insert_btn.TabIndex = 24;
            this.insert_btn.Text = "新增";
            this.insert_btn.UseVisualStyleBackColor = true;
            this.insert_btn.Click += new System.EventHandler(this.insert_btn_Click);
            // 
            // delete_btn
            // 
            this.delete_btn.Location = new System.Drawing.Point(390, 579);
            this.delete_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.delete_btn.Name = "delete_btn";
            this.delete_btn.Size = new System.Drawing.Size(84, 28);
            this.delete_btn.TabIndex = 25;
            this.delete_btn.Text = "删除";
            this.delete_btn.UseVisualStyleBackColor = true;
            this.delete_btn.Click += new System.EventHandler(this.delete_btn_Click);
            // 
            // selectconditionsgroupBox6
            // 
            this.selectconditionsgroupBox6.Controls.Add(this.rid_text);
            this.selectconditionsgroupBox6.Controls.Add(this.ifOverdue_combo);
            this.selectconditionsgroupBox6.Controls.Add(this.label3);
            this.selectconditionsgroupBox6.Controls.Add(this.CheckOutDate_text);
            this.selectconditionsgroupBox6.Controls.Add(this.label2);
            this.selectconditionsgroupBox6.Controls.Add(this.ReturnDate_text);
            this.selectconditionsgroupBox6.Controls.Add(this.label1);
            this.selectconditionsgroupBox6.Controls.Add(this.DeadLine_text);
            this.selectconditionsgroupBox6.Controls.Add(this.fine_text);
            this.selectconditionsgroupBox6.Controls.Add(this.ISBNum_text);
            this.selectconditionsgroupBox6.Controls.Add(this.BRno_text);
            this.selectconditionsgroupBox6.Controls.Add(this.presslabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.collectionnumlabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.yesnoborrowlabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.writerlabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.ISBNlabel6);
            this.selectconditionsgroupBox6.Location = new System.Drawing.Point(45, 79);
            this.selectconditionsgroupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectconditionsgroupBox6.Name = "selectconditionsgroupBox6";
            this.selectconditionsgroupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectconditionsgroupBox6.Size = new System.Drawing.Size(824, 140);
            this.selectconditionsgroupBox6.TabIndex = 18;
            this.selectconditionsgroupBox6.TabStop = false;
            this.selectconditionsgroupBox6.Text = "查询条件";
            // 
            // rid_text
            // 
            this.rid_text.Location = new System.Drawing.Point(122, 86);
            this.rid_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rid_text.Name = "rid_text";
            this.rid_text.Size = new System.Drawing.Size(112, 28);
            this.rid_text.TabIndex = 26;
            // 
            // ifOverdue_combo
            // 
            this.ifOverdue_combo.FormattingEnabled = true;
            this.ifOverdue_combo.Items.AddRange(new object[] {
            "是",
            "否"});
            this.ifOverdue_combo.Location = new System.Drawing.Point(705, 92);
            this.ifOverdue_combo.Name = "ifOverdue_combo";
            this.ifOverdue_combo.Size = new System.Drawing.Size(112, 26);
            this.ifOverdue_combo.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(619, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 24;
            this.label3.Text = "是否逾期";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // CheckOutDate_text
            // 
            this.CheckOutDate_text.Location = new System.Drawing.Point(439, 34);
            this.CheckOutDate_text.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.CheckOutDate_text.Name = "CheckOutDate_text";
            this.CheckOutDate_text.Size = new System.Drawing.Size(165, 28);
            this.CheckOutDate_text.TabIndex = 23;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(436, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "借出日期";
            // 
            // ReturnDate_text
            // 
            this.ReturnDate_text.Location = new System.Drawing.Point(439, 96);
            this.ReturnDate_text.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.ReturnDate_text.Name = "ReturnDate_text";
            this.ReturnDate_text.Size = new System.Drawing.Size(165, 28);
            this.ReturnDate_text.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(436, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "返还日期";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // DeadLine_text
            // 
            this.DeadLine_text.Location = new System.Drawing.Point(638, 34);
            this.DeadLine_text.MinDate = new System.DateTime(1800, 1, 1, 0, 0, 0, 0);
            this.DeadLine_text.Name = "DeadLine_text";
            this.DeadLine_text.Size = new System.Drawing.Size(178, 28);
            this.DeadLine_text.TabIndex = 19;
            this.DeadLine_text.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // presslabel6
            // 
            this.presslabel6.AutoSize = true;
            this.presslabel6.Location = new System.Drawing.Point(256, 93);
            this.presslabel6.Name = "presslabel6";
            this.presslabel6.Size = new System.Drawing.Size(44, 18);
            this.presslabel6.TabIndex = 5;
            this.presslabel6.Text = "罚款";
            // 
            // update_btn
            // 
            this.update_btn.Location = new System.Drawing.Point(722, 579);
            this.update_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(84, 28);
            this.update_btn.TabIndex = 26;
            this.update_btn.Text = "修改";
            this.update_btn.UseVisualStyleBackColor = true;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // BR
            // 
            this.BR.Location = new System.Drawing.Point(236, 42);
            this.BR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BR.Name = "BR";
            this.BR.Size = new System.Drawing.Size(136, 29);
            this.BR.TabIndex = 29;
            this.BR.Text = "借阅图书信息";
            this.BR.UseVisualStyleBackColor = true;
            // 
            // Books
            // 
            this.Books.Location = new System.Drawing.Point(146, 43);
            this.Books.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Books.Name = "Books";
            this.Books.Size = new System.Drawing.Size(98, 28);
            this.Books.TabIndex = 28;
            this.Books.Text = "图书信息";
            this.Books.UseVisualStyleBackColor = true;
            this.Books.Click += new System.EventHandler(this.Books_Click);
            // 
            // Readers
            // 
            this.Readers.Location = new System.Drawing.Point(51, 43);
            this.Readers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Readers.Name = "Readers";
            this.Readers.Size = new System.Drawing.Size(98, 28);
            this.Readers.TabIndex = 27;
            this.Readers.Text = "读者信息";
            this.Readers.UseVisualStyleBackColor = true;
            this.Readers.Click += new System.EventHandler(this.Readers_Click);
            // 
            // BR_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(930, 618);
            this.Controls.Add(this.BR);
            this.Controls.Add(this.Books);
            this.Controls.Add(this.Readers);
            this.Controls.Add(this.update_btn);
            this.Controls.Add(this.reset_btn);
            this.Controls.Add(this.select_btn);
            this.Controls.Add(this.selectresultsgroupBox6);
            this.Controls.Add(this.insert_btn);
            this.Controls.Add(this.delete_btn);
            this.Controls.Add(this.selectconditionsgroupBox6);
            this.Name = "BR_admin";
            this.Text = "BR_admin";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BR_admin_FormClosing);
            this.Load += new System.EventHandler(this.BR_admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.selectresults)).EndInit();
            this.selectresultsgroupBox6.ResumeLayout(false);
            this.selectconditionsgroupBox6.ResumeLayout(false);
            this.selectconditionsgroupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.Label collectionnumlabel6;
        private System.Windows.Forms.Label yesnoborrowlabel6;
        private System.Windows.Forms.Label writerlabel6;
        private System.Windows.Forms.Label ISBNlabel6;
        private System.Windows.Forms.Button refresh_btn;
        private System.Windows.Forms.DataGridView selectresults;
        private System.Windows.Forms.Button select_btn;
        private System.Windows.Forms.GroupBox selectresultsgroupBox6;
        private System.Windows.Forms.TextBox fine_text;
        private System.Windows.Forms.TextBox ISBNum_text;
        private System.Windows.Forms.TextBox BRno_text;
        private System.Windows.Forms.Button insert_btn;
        private System.Windows.Forms.Button delete_btn;
        private System.Windows.Forms.GroupBox selectconditionsgroupBox6;
        private System.Windows.Forms.Label presslabel6;
        private System.Windows.Forms.ComboBox ifOverdue_combo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker CheckOutDate_text;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker ReturnDate_text;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker DeadLine_text;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.TextBox rid_text;
        private System.Windows.Forms.Button BR;
        private System.Windows.Forms.Button Books;
        private System.Windows.Forms.Button Readers;
    }
}