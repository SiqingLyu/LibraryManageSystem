﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class BR_reader : Form
    {
        public string sql_default = "select * from BR where BRno = '-1'";
        public string Mindt = "1900/1/1";
        public BR_reader()
        {
            InitializeComponent();
            bookname_text.Text = "";
            ISBNum_text.Text = "";

        }

        private void select_btn_Click(object sender, EventArgs e)
        {
            string booknameStr = bookname_text.Text.Trim();
            string ISBNStr = ISBNum_text.Text.Trim();
            string BRselect_admin = String.Format("select * from BR where rid = '{0}' and ISBNum like'%{1}%' and exists(select * from Books where Books.ISBNum = BR.ISBNum and Books.bname like '%{2}%')"
                                                                ,  publicVar.currentRid.Trim(),ISBNStr,booknameStr);
          
            this.selectresults.DataSource = DBoperations.Query(BRselect_admin).Tables["ds"];
            sql_default = BRselect_admin;
          
        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            bookname_text.Text = "";
            ISBNum_text.Text = "";
            
        }

        private void refresh_btn_Click(object sender, EventArgs e)
        {

            this.selectresults.DataSource = DBoperations.Query(sql_default).Tables["ds"];
        }

        private void Readers_Click(object sender, EventArgs e)
        {
            ReadersForm_reader readersForm_Reader = new ReadersForm_reader();
            readersForm_Reader.Show();
            this.Dispose();
        }

        private void Books_Click(object sender, EventArgs e)
        {
            BooksFrom_reader booksFrom_Reader = new BooksFrom_reader();
            booksFrom_Reader.Show();
            this.Dispose();
        }

        private void BR_Click(object sender, EventArgs e)
        {

        }

        private void return_btn_Click(object sender, EventArgs e)
        {
            try
            {
                int index = selectresults.CurrentRow.Index;
                string BRnoStr = selectresults.Rows[index].Cells[0].Value.ToString().Trim();

                string ReturnDate = selectresults.Rows[index].Cells[5].Value.ToString().Trim();
                string DeadLine = selectresults.Rows[index].Cells[4].Value.ToString().Trim();
                DateTime dt1 = Convert.ToDateTime(DeadLine);
                DateTime dt2 = Convert.ToDateTime(ReturnDate);
                DateTime dt3 = Convert.ToDateTime(Mindt);
                Console.WriteLine("归还日期：{0}\n 最小日期： {1}", dt2.ToString().Trim(), dt3.ToString().Trim());
                if (DateTime.Compare(dt3,dt2) != 0)
                {
                    
                    MessageBox.Show("已经归还过该书籍！");
                    return;
                }
                ReturnDate = DateTime.Now.ToShortDateString().ToString().Trim();
                dt1 = Convert.ToDateTime(DeadLine);
                dt2 = Convert.ToDateTime(ReturnDate);
                dt3 = Convert.ToDateTime(Mindt);


                string deleteSql = String.Format("\n update BR set ReturnDate='{0}' where BRno = '{1}'",ReturnDate, BRnoStr);
                string confirmMess = String.Format("确认还书？", selectresults.Rows[index].Cells[0].Value.ToString().Trim());
                Console.WriteLine("DateTime.Compare(dt1, dt2) < 0:  {0}", DateTime.Compare(dt1, dt2) < 0);
                if (DateTime.Compare(dt1, dt2) < 0)
                {
                    TimeSpan ts1 = new TimeSpan(dt1.Ticks);
                    TimeSpan ts2 = new TimeSpan(dt2.Ticks);
                    TimeSpan ts3 = ts2.Subtract(ts1); //ts2-ts1
                    int sumdays = int.Parse(ts3.TotalDays.ToString()); //得到相差天数
                    if (sumdays > 0) //确认是否超时
                    {
                        double fine_topay = (sumdays) * 0.2;
                        MessageBox.Show(String.Format("借书超时,将罚款人民币 {0} 元", fine_topay.ToString().Trim()));
                        deleteSql += String.Format("\nupdate BR set fine = {0} where BRno = '{1}'",fine_topay.ToString().Trim(),BRnoStr);
                    }

                }

                deleteSql += String.Format("\nupdate Readers set ravailable = ravailable+1 where rid = '{0}'",publicVar.currentRid.Trim());
                deleteSql += String.Format("\nupdate Books set bnumAvailable = bnumavailable + 1 where exists(select * from BR where BRno = {0} and BR.ISBNum = Books.ISBNum)",BRnoStr);
                if (MessageBox.Show(confirmMess, "还书确认", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    if (DBoperations.ExecuteSql(deleteSql) > 0) //rows > 0
                    {

                        MessageBox.Show("还书成功");
                       
                    }
                    else
                    {
                        MessageBox.Show("还书失败！");
                    }
                }
            }
            catch (NullReferenceException NotRefE)
            {
                MessageBox.Show("未选择删除对象！");
                return;
            }
        }

        private void BR_reader_Load(object sender, EventArgs e)
        {
            this.Text = "读者界面——借阅信息查询";
        }

        private void BR_reader_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.FormClosing -= BR_reader_FormClosing;
            Application.Exit();
        }

        private void BooksIndue_btn_Click(object sender, EventArgs e)
        {
            string OverDueSQL = String.Format(@"select *

                                                from BR

                                                where  DeadLine <=  DATENAME(YEAR,GETDATE())+'/'+DATENAME(MONTH,GETDATE())+'/'+DATENAME(DAY,GETDATE()) and ReturnDate = '1900/1/1'
			                                    and BR.rid ='{0}'", publicVar.currentRid.Trim());
            this.selectresults.DataSource = DBoperations.Query(OverDueSQL).Tables["ds"];

        }

        private void payFine_btn_Click(object sender, EventArgs e)
        {
            
        }

        private void PayFine_Click(object sender, EventArgs e)
        {
            string FineAllSQL = String.Format("select SUM(fine) from BR where BR.rid='{0}'", publicVar.currentRid.Trim());
            this.selectresults.DataSource = DBoperations.Query(FineAllSQL).Tables["ds"];

            string FineAll = selectresults.Rows[0].Cells[0].Value.ToString().Trim();
            if(FineAll == "0")
            {
                MessageBox.Show("没有需要缴纳的罚款！");
            }
            else if(MessageBox.Show("共需缴纳罚款"+FineAll+"元", "缴纳确认", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                string PaySQL = String.Format("update BR set fine=0 where rid = {0} and fine > 0 ", publicVar.currentRid.Trim());
                if (DBoperations.ExecuteSql(PaySQL) > 0) //rows > 0
                {

                    MessageBox.Show("缴纳罚款成功");

                }
                else
                {
                    MessageBox.Show("缴纳罚款失败！");
                }
            }
        }
    }
}
