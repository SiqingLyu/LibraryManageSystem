﻿namespace DataBase_Library
{
    partial class signin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name = new System.Windows.Forms.TextBox();
            this.passwd = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.id_box = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.signin_confirm = new System.Windows.Forms.Button();
            this.ReaderInfoGroup = new System.Windows.Forms.GroupBox();
            this.rtel_text = new System.Windows.Forms.TextBox();
            this.rtel = new System.Windows.Forms.Label();
            this.rsex_combo = new System.Windows.Forms.ComboBox();
            this.rworkplace_text = new System.Windows.Forms.TextBox();
            this.rjob_text = new System.Windows.Forms.TextBox();
            this.rworkplace = new System.Windows.Forms.Label();
            this.rsex = new System.Windows.Forms.Label();
            this.rjob = new System.Windows.Forms.Label();
            this.Rid = new System.Windows.Forms.Label();
            this.Rid_text = new System.Windows.Forms.TextBox();
            this.adminCertify_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.AdminCertifyGroup = new System.Windows.Forms.GroupBox();
            this.ReaderInfoGroup.SuspendLayout();
            this.AdminCertifyGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(103, 55);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(167, 28);
            this.name.TabIndex = 0;
            // 
            // passwd
            // 
            this.passwd.Location = new System.Drawing.Point(361, 55);
            this.passwd.Name = "passwd";
            this.passwd.Size = new System.Drawing.Size(167, 28);
            this.passwd.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "用户名";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(293, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "密码";
            // 
            // id_box
            // 
            this.id_box.FormattingEnabled = true;
            this.id_box.Items.AddRange(new object[] {
            "admin",
            "reader"});
            this.id_box.Location = new System.Drawing.Point(623, 57);
            this.id_box.Name = "id_box";
            this.id_box.Size = new System.Drawing.Size(167, 26);
            this.id_box.TabIndex = 4;
            this.id_box.Text = "下拉选择";
            this.id_box.SelectedIndexChanged += new System.EventHandler(this.id_box_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(556, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "身份";
            // 
            // signin_confirm
            // 
            this.signin_confirm.Location = new System.Drawing.Point(296, 302);
            this.signin_confirm.Name = "signin_confirm";
            this.signin_confirm.Size = new System.Drawing.Size(220, 60);
            this.signin_confirm.TabIndex = 6;
            this.signin_confirm.Text = "注册";
            this.signin_confirm.UseVisualStyleBackColor = true;
            this.signin_confirm.Click += new System.EventHandler(this.signin_confirm_Click);
            // 
            // ReaderInfoGroup
            // 
            this.ReaderInfoGroup.Controls.Add(this.rtel_text);
            this.ReaderInfoGroup.Controls.Add(this.rtel);
            this.ReaderInfoGroup.Controls.Add(this.rsex_combo);
            this.ReaderInfoGroup.Controls.Add(this.rworkplace_text);
            this.ReaderInfoGroup.Controls.Add(this.rjob_text);
            this.ReaderInfoGroup.Controls.Add(this.rworkplace);
            this.ReaderInfoGroup.Controls.Add(this.rsex);
            this.ReaderInfoGroup.Controls.Add(this.rjob);
            this.ReaderInfoGroup.Controls.Add(this.Rid);
            this.ReaderInfoGroup.Controls.Add(this.Rid_text);
            this.ReaderInfoGroup.Location = new System.Drawing.Point(12, 131);
            this.ReaderInfoGroup.Name = "ReaderInfoGroup";
            this.ReaderInfoGroup.Size = new System.Drawing.Size(796, 165);
            this.ReaderInfoGroup.TabIndex = 33;
            this.ReaderInfoGroup.TabStop = false;
            this.ReaderInfoGroup.Text = "readerInfo";
            // 
            // rtel_text
            // 
            this.rtel_text.Location = new System.Drawing.Point(378, 98);
            this.rtel_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtel_text.Name = "rtel_text";
            this.rtel_text.Size = new System.Drawing.Size(112, 28);
            this.rtel_text.TabIndex = 42;
            // 
            // rtel
            // 
            this.rtel.AutoSize = true;
            this.rtel.Location = new System.Drawing.Point(328, 101);
            this.rtel.Name = "rtel";
            this.rtel.Size = new System.Drawing.Size(44, 18);
            this.rtel.TabIndex = 41;
            this.rtel.Text = "电话";
            // 
            // rsex_combo
            // 
            this.rsex_combo.FormattingEnabled = true;
            this.rsex_combo.Items.AddRange(new object[] {
            "男",
            "女"});
            this.rsex_combo.Location = new System.Drawing.Point(111, 95);
            this.rsex_combo.Name = "rsex_combo";
            this.rsex_combo.Size = new System.Drawing.Size(112, 26);
            this.rsex_combo.TabIndex = 40;
            // 
            // rworkplace_text
            // 
            this.rworkplace_text.Location = new System.Drawing.Point(611, 36);
            this.rworkplace_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rworkplace_text.Name = "rworkplace_text";
            this.rworkplace_text.Size = new System.Drawing.Size(112, 28);
            this.rworkplace_text.TabIndex = 39;
            // 
            // rjob_text
            // 
            this.rjob_text.Location = new System.Drawing.Point(378, 36);
            this.rjob_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rjob_text.Name = "rjob_text";
            this.rjob_text.Size = new System.Drawing.Size(112, 28);
            this.rjob_text.TabIndex = 38;
            // 
            // rworkplace
            // 
            this.rworkplace.AutoSize = true;
            this.rworkplace.Location = new System.Drawing.Point(533, 42);
            this.rworkplace.Name = "rworkplace";
            this.rworkplace.Size = new System.Drawing.Size(80, 18);
            this.rworkplace.TabIndex = 37;
            this.rworkplace.Text = "工作地点";
            // 
            // rsex
            // 
            this.rsex.AutoSize = true;
            this.rsex.Location = new System.Drawing.Point(61, 98);
            this.rsex.Name = "rsex";
            this.rsex.Size = new System.Drawing.Size(44, 18);
            this.rsex.TabIndex = 36;
            this.rsex.Text = "性别";
            // 
            // rjob
            // 
            this.rjob.AutoSize = true;
            this.rjob.Location = new System.Drawing.Point(292, 39);
            this.rjob.Name = "rjob";
            this.rjob.Size = new System.Drawing.Size(80, 18);
            this.rjob.TabIndex = 35;
            this.rjob.Text = "工作职称";
            // 
            // Rid
            // 
            this.Rid.AutoSize = true;
            this.Rid.Location = new System.Drawing.Point(25, 39);
            this.Rid.Name = "Rid";
            this.Rid.Size = new System.Drawing.Size(80, 18);
            this.Rid.TabIndex = 34;
            this.Rid.Text = "读书卡号";
            // 
            // Rid_text
            // 
            this.Rid_text.Location = new System.Drawing.Point(111, 36);
            this.Rid_text.Name = "Rid_text";
            this.Rid_text.Size = new System.Drawing.Size(167, 28);
            this.Rid_text.TabIndex = 33;
            // 
            // adminCertify_txt
            // 
            this.adminCertify_txt.Location = new System.Drawing.Point(258, 27);
            this.adminCertify_txt.Name = "adminCertify_txt";
            this.adminCertify_txt.Size = new System.Drawing.Size(167, 28);
            this.adminCertify_txt.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(136, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 18);
            this.label4.TabIndex = 35;
            this.label4.Text = "管理员验证码";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // AdminCertifyGroup
            // 
            this.AdminCertifyGroup.Controls.Add(this.label4);
            this.AdminCertifyGroup.Controls.Add(this.adminCertify_txt);
            this.AdminCertifyGroup.Location = new System.Drawing.Point(103, 108);
            this.AdminCertifyGroup.Name = "AdminCertifyGroup";
            this.AdminCertifyGroup.Size = new System.Drawing.Size(453, 112);
            this.AdminCertifyGroup.TabIndex = 43;
            this.AdminCertifyGroup.TabStop = false;
            this.AdminCertifyGroup.Text = "管理员认证";
            // 
            // signin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 383);
            this.Controls.Add(this.AdminCertifyGroup);
            this.Controls.Add(this.ReaderInfoGroup);
            this.Controls.Add(this.signin_confirm);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.id_box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.passwd);
            this.Controls.Add(this.name);
            this.Name = "signin";
            this.Text = "signin";
            this.Load += new System.EventHandler(this.signin_Load);
            this.ReaderInfoGroup.ResumeLayout(false);
            this.ReaderInfoGroup.PerformLayout();
            this.AdminCertifyGroup.ResumeLayout(false);
            this.AdminCertifyGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox passwd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox id_box;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button signin_confirm;
        private System.Windows.Forms.GroupBox ReaderInfoGroup;
        private System.Windows.Forms.TextBox rtel_text;
        private System.Windows.Forms.Label rtel;
        private System.Windows.Forms.ComboBox rsex_combo;
        private System.Windows.Forms.TextBox rworkplace_text;
        private System.Windows.Forms.TextBox rjob_text;
        private System.Windows.Forms.Label rworkplace;
        private System.Windows.Forms.Label rsex;
        private System.Windows.Forms.Label rjob;
        private System.Windows.Forms.Label Rid;
        private System.Windows.Forms.TextBox Rid_text;
        private System.Windows.Forms.TextBox adminCertify_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox AdminCertifyGroup;
    }
}