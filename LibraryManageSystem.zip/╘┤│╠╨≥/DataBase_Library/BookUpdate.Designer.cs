﻿namespace DataBase_Library
{
    partial class BookUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reset_btn = new System.Windows.Forms.Button();
            this.ifAvailable_combo = new System.Windows.Forms.ComboBox();
            this.numAvailable_text = new System.Windows.Forms.TextBox();
            this.totalnum_text = new System.Windows.Forms.TextBox();
            this.press_text = new System.Windows.Forms.TextBox();
            this.bookname_text = new System.Windows.Forms.TextBox();
            this.writer_text = new System.Windows.Forms.TextBox();
            this.ISBN_text = new System.Windows.Forms.TextBox();
            this.canborrownumlabel6 = new System.Windows.Forms.Label();
            this.presslabel6 = new System.Windows.Forms.Label();
            this.booknamelabel6 = new System.Windows.Forms.Label();
            this.collectionnumlabel6 = new System.Windows.Forms.Label();
            this.yesnoborrowlabel6 = new System.Windows.Forms.Label();
            this.writerlabel6 = new System.Windows.Forms.Label();
            this.ISBNlabel6 = new System.Windows.Forms.Label();
            this.update_group = new System.Windows.Forms.GroupBox();
            this.update_confirm = new System.Windows.Forms.Button();
            this.update_cancel = new System.Windows.Forms.Button();
            this.update_group.SuspendLayout();
            this.SuspendLayout();
            // 
            // reset_btn
            // 
            this.reset_btn.Location = new System.Drawing.Point(697, 88);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(75, 33);
            this.reset_btn.TabIndex = 18;
            this.reset_btn.Text = "复位";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // ifAvailable_combo
            // 
            this.ifAvailable_combo.FormattingEnabled = true;
            this.ifAvailable_combo.Items.AddRange(new object[] {
            "是",
            "否"});
            this.ifAvailable_combo.Location = new System.Drawing.Point(488, 30);
            this.ifAvailable_combo.Name = "ifAvailable_combo";
            this.ifAvailable_combo.Size = new System.Drawing.Size(112, 26);
            this.ifAvailable_combo.TabIndex = 14;
            // 
            // numAvailable_text
            // 
            this.numAvailable_text.Location = new System.Drawing.Point(488, 88);
            this.numAvailable_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numAvailable_text.Name = "numAvailable_text";
            this.numAvailable_text.Size = new System.Drawing.Size(112, 28);
            this.numAvailable_text.TabIndex = 13;
            // 
            // totalnum_text
            // 
            this.totalnum_text.Location = new System.Drawing.Point(686, 28);
            this.totalnum_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.totalnum_text.Name = "totalnum_text";
            this.totalnum_text.Size = new System.Drawing.Size(112, 28);
            this.totalnum_text.TabIndex = 12;
            // 
            // press_text
            // 
            this.press_text.Location = new System.Drawing.Point(288, 88);
            this.press_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.press_text.Name = "press_text";
            this.press_text.Size = new System.Drawing.Size(112, 28);
            this.press_text.TabIndex = 10;
            // 
            // bookname_text
            // 
            this.bookname_text.Location = new System.Drawing.Point(104, 88);
            this.bookname_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bookname_text.Name = "bookname_text";
            this.bookname_text.Size = new System.Drawing.Size(112, 28);
            this.bookname_text.TabIndex = 9;
            // 
            // writer_text
            // 
            this.writer_text.Location = new System.Drawing.Point(288, 28);
            this.writer_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.writer_text.Name = "writer_text";
            this.writer_text.Size = new System.Drawing.Size(112, 28);
            this.writer_text.TabIndex = 8;
            // 
            // ISBN_text
            // 
            this.ISBN_text.Location = new System.Drawing.Point(104, 28);
            this.ISBN_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ISBN_text.Name = "ISBN_text";
            this.ISBN_text.Size = new System.Drawing.Size(112, 28);
            this.ISBN_text.TabIndex = 7;
            // 
            // canborrownumlabel6
            // 
            this.canborrownumlabel6.AutoSize = true;
            this.canborrownumlabel6.Location = new System.Drawing.Point(407, 92);
            this.canborrownumlabel6.Name = "canborrownumlabel6";
            this.canborrownumlabel6.Size = new System.Drawing.Size(80, 18);
            this.canborrownumlabel6.TabIndex = 6;
            this.canborrownumlabel6.Text = "可借数量";
            // 
            // presslabel6
            // 
            this.presslabel6.AutoSize = true;
            this.presslabel6.Location = new System.Drawing.Point(223, 92);
            this.presslabel6.Name = "presslabel6";
            this.presslabel6.Size = new System.Drawing.Size(62, 18);
            this.presslabel6.TabIndex = 5;
            this.presslabel6.Text = "出版社";
            // 
            // booknamelabel6
            // 
            this.booknamelabel6.AutoSize = true;
            this.booknamelabel6.Location = new System.Drawing.Point(55, 92);
            this.booknamelabel6.Name = "booknamelabel6";
            this.booknamelabel6.Size = new System.Drawing.Size(44, 18);
            this.booknamelabel6.TabIndex = 4;
            this.booknamelabel6.Text = "书名";
            // 
            // collectionnumlabel6
            // 
            this.collectionnumlabel6.AutoSize = true;
            this.collectionnumlabel6.Location = new System.Drawing.Point(608, 34);
            this.collectionnumlabel6.Name = "collectionnumlabel6";
            this.collectionnumlabel6.Size = new System.Drawing.Size(80, 18);
            this.collectionnumlabel6.TabIndex = 3;
            this.collectionnumlabel6.Text = "馆藏数量";
            // 
            // yesnoborrowlabel6
            // 
            this.yesnoborrowlabel6.AutoSize = true;
            this.yesnoborrowlabel6.Location = new System.Drawing.Point(406, 34);
            this.yesnoborrowlabel6.Name = "yesnoborrowlabel6";
            this.yesnoborrowlabel6.Size = new System.Drawing.Size(80, 18);
            this.yesnoborrowlabel6.TabIndex = 2;
            this.yesnoborrowlabel6.Text = "是否可借";
            // 
            // writerlabel6
            // 
            this.writerlabel6.AutoSize = true;
            this.writerlabel6.Location = new System.Drawing.Point(238, 34);
            this.writerlabel6.Name = "writerlabel6";
            this.writerlabel6.Size = new System.Drawing.Size(44, 18);
            this.writerlabel6.TabIndex = 1;
            this.writerlabel6.Text = "作者";
            // 
            // ISBNlabel6
            // 
            this.ISBNlabel6.AutoSize = true;
            this.ISBNlabel6.Location = new System.Drawing.Point(19, 34);
            this.ISBNlabel6.Name = "ISBNlabel6";
            this.ISBNlabel6.Size = new System.Drawing.Size(80, 18);
            this.ISBNlabel6.TabIndex = 0;
            this.ISBNlabel6.Text = "ISBN书号";
            // 
            // update_group
            // 
            this.update_group.Controls.Add(this.reset_btn);
            this.update_group.Controls.Add(this.ifAvailable_combo);
            this.update_group.Controls.Add(this.numAvailable_text);
            this.update_group.Controls.Add(this.totalnum_text);
            this.update_group.Controls.Add(this.press_text);
            this.update_group.Controls.Add(this.bookname_text);
            this.update_group.Controls.Add(this.writer_text);
            this.update_group.Controls.Add(this.ISBN_text);
            this.update_group.Controls.Add(this.canborrownumlabel6);
            this.update_group.Controls.Add(this.presslabel6);
            this.update_group.Controls.Add(this.booknamelabel6);
            this.update_group.Controls.Add(this.collectionnumlabel6);
            this.update_group.Controls.Add(this.yesnoborrowlabel6);
            this.update_group.Controls.Add(this.writerlabel6);
            this.update_group.Controls.Add(this.ISBNlabel6);
            this.update_group.Location = new System.Drawing.Point(45, 93);
            this.update_group.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_group.Name = "update_group";
            this.update_group.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_group.Size = new System.Drawing.Size(824, 140);
            this.update_group.TabIndex = 10;
            this.update_group.TabStop = false;
            this.update_group.Text = "修改";
            this.update_group.Enter += new System.EventHandler(this.selectconditionsgroupBox6_Enter);
            // 
            // update_confirm
            // 
            this.update_confirm.Location = new System.Drawing.Point(196, 318);
            this.update_confirm.Name = "update_confirm";
            this.update_confirm.Size = new System.Drawing.Size(118, 43);
            this.update_confirm.TabIndex = 19;
            this.update_confirm.Text = "确认";
            this.update_confirm.UseVisualStyleBackColor = true;
            this.update_confirm.Click += new System.EventHandler(this.button1_Click);
            // 
            // update_cancel
            // 
            this.update_cancel.Location = new System.Drawing.Point(573, 318);
            this.update_cancel.Name = "update_cancel";
            this.update_cancel.Size = new System.Drawing.Size(118, 43);
            this.update_cancel.TabIndex = 20;
            this.update_cancel.Text = "取消";
            this.update_cancel.UseVisualStyleBackColor = true;
            this.update_cancel.Click += new System.EventHandler(this.update_cancel_Click);
            // 
            // BookUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 480);
            this.Controls.Add(this.update_cancel);
            this.Controls.Add(this.update_confirm);
            this.Controls.Add(this.update_group);
            this.Name = "BookUpdate";
            this.Text = "BookUpdate";
            this.Load += new System.EventHandler(this.BookUpdate_Load);
            this.update_group.ResumeLayout(false);
            this.update_group.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.ComboBox ifAvailable_combo;
        private System.Windows.Forms.TextBox numAvailable_text;
        private System.Windows.Forms.TextBox totalnum_text;
        private System.Windows.Forms.TextBox press_text;
        private System.Windows.Forms.TextBox bookname_text;
        private System.Windows.Forms.TextBox writer_text;
        private System.Windows.Forms.TextBox ISBN_text;
        private System.Windows.Forms.Label canborrownumlabel6;
        private System.Windows.Forms.Label presslabel6;
        private System.Windows.Forms.Label booknamelabel6;
        private System.Windows.Forms.Label collectionnumlabel6;
        private System.Windows.Forms.Label yesnoborrowlabel6;
        private System.Windows.Forms.Label writerlabel6;
        private System.Windows.Forms.Label ISBNlabel6;
        private System.Windows.Forms.GroupBox update_group;
        private System.Windows.Forms.Button update_confirm;
        private System.Windows.Forms.Button update_cancel;
    }
}