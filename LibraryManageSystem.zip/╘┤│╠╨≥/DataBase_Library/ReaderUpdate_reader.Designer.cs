﻿namespace DataBase_Library
{
    partial class ReaderUpdate_reader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtel_text = new System.Windows.Forms.TextBox();
            this.l8 = new System.Windows.Forms.Label();
            this.rsex_combo = new System.Windows.Forms.ComboBox();
            this.rworkplace_text = new System.Windows.Forms.TextBox();
            this.rjob_text = new System.Windows.Forms.TextBox();
            this.Available_sum = new System.Windows.Forms.Label();
            this.Already_sum = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.l3 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.reset_btn = new System.Windows.Forms.Button();
            this.update_cancel = new System.Windows.Forms.Button();
            this.update_confirm = new System.Windows.Forms.Button();
            this.update_group = new System.Windows.Forms.GroupBox();
            this.name_label = new System.Windows.Forms.Label();
            this.rid_label = new System.Windows.Forms.Label();
            this.GetInfo = new System.Windows.Forms.DataGridView();
            this.update_group.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GetInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // rtel_text
            // 
            this.rtel_text.Location = new System.Drawing.Point(746, 31);
            this.rtel_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtel_text.Name = "rtel_text";
            this.rtel_text.Size = new System.Drawing.Size(112, 28);
            this.rtel_text.TabIndex = 16;
            // 
            // l8
            // 
            this.l8.AutoSize = true;
            this.l8.Location = new System.Drawing.Point(696, 34);
            this.l8.Name = "l8";
            this.l8.Size = new System.Drawing.Size(44, 18);
            this.l8.TabIndex = 15;
            this.l8.Text = "电话";
            // 
            // rsex_combo
            // 
            this.rsex_combo.FormattingEnabled = true;
            this.rsex_combo.Items.AddRange(new object[] {
            "男",
            "女"});
            this.rsex_combo.Location = new System.Drawing.Point(327, 33);
            this.rsex_combo.Name = "rsex_combo";
            this.rsex_combo.Size = new System.Drawing.Size(112, 26);
            this.rsex_combo.TabIndex = 14;
            // 
            // rworkplace_text
            // 
            this.rworkplace_text.Location = new System.Drawing.Point(563, 31);
            this.rworkplace_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rworkplace_text.Name = "rworkplace_text";
            this.rworkplace_text.Size = new System.Drawing.Size(112, 28);
            this.rworkplace_text.TabIndex = 12;
            // 
            // rjob_text
            // 
            this.rjob_text.Location = new System.Drawing.Point(117, 33);
            this.rjob_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rjob_text.Name = "rjob_text";
            this.rjob_text.Size = new System.Drawing.Size(112, 28);
            this.rjob_text.TabIndex = 8;
            // 
            // Available_sum
            // 
            this.Available_sum.AutoSize = true;
            this.Available_sum.Location = new System.Drawing.Point(245, 98);
            this.Available_sum.Name = "Available_sum";
            this.Available_sum.Size = new System.Drawing.Size(80, 18);
            this.Available_sum.TabIndex = 6;
            this.Available_sum.Text = "可借数量";
            this.Available_sum.Click += new System.EventHandler(this.l7_Click);
            // 
            // Already_sum
            // 
            this.Already_sum.AutoSize = true;
            this.Already_sum.Location = new System.Drawing.Point(31, 98);
            this.Already_sum.Name = "Already_sum";
            this.Already_sum.Size = new System.Drawing.Size(80, 18);
            this.Already_sum.TabIndex = 5;
            this.Already_sum.Text = "已借数量";
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Location = new System.Drawing.Point(477, 35);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(80, 18);
            this.l4.TabIndex = 3;
            this.l4.Text = "工作地点";
            // 
            // l3
            // 
            this.l3.AutoSize = true;
            this.l3.Location = new System.Drawing.Point(277, 36);
            this.l3.Name = "l3";
            this.l3.Size = new System.Drawing.Size(44, 18);
            this.l3.TabIndex = 2;
            this.l3.Text = "性别";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Location = new System.Drawing.Point(31, 36);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(80, 18);
            this.l2.TabIndex = 1;
            this.l2.Text = "工作职称";
            // 
            // reset_btn
            // 
            this.reset_btn.Location = new System.Drawing.Point(950, 259);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(75, 33);
            this.reset_btn.TabIndex = 24;
            this.reset_btn.Text = "复位";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // update_cancel
            // 
            this.update_cancel.Location = new System.Drawing.Point(735, 337);
            this.update_cancel.Name = "update_cancel";
            this.update_cancel.Size = new System.Drawing.Size(118, 43);
            this.update_cancel.TabIndex = 27;
            this.update_cancel.Text = "取消";
            this.update_cancel.UseVisualStyleBackColor = true;
            this.update_cancel.Click += new System.EventHandler(this.update_cancel_Click);
            // 
            // update_confirm
            // 
            this.update_confirm.Location = new System.Drawing.Point(358, 337);
            this.update_confirm.Name = "update_confirm";
            this.update_confirm.Size = new System.Drawing.Size(118, 43);
            this.update_confirm.TabIndex = 26;
            this.update_confirm.Text = "确认";
            this.update_confirm.UseVisualStyleBackColor = true;
            this.update_confirm.Click += new System.EventHandler(this.update_confirm_Click);
            // 
            // update_group
            // 
            this.update_group.Controls.Add(this.name_label);
            this.update_group.Controls.Add(this.rid_label);
            this.update_group.Controls.Add(this.rtel_text);
            this.update_group.Controls.Add(this.l8);
            this.update_group.Controls.Add(this.rsex_combo);
            this.update_group.Controls.Add(this.rworkplace_text);
            this.update_group.Controls.Add(this.rjob_text);
            this.update_group.Controls.Add(this.Available_sum);
            this.update_group.Controls.Add(this.Already_sum);
            this.update_group.Controls.Add(this.l4);
            this.update_group.Controls.Add(this.l3);
            this.update_group.Controls.Add(this.l2);
            this.update_group.Location = new System.Drawing.Point(151, 112);
            this.update_group.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_group.Name = "update_group";
            this.update_group.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_group.Size = new System.Drawing.Size(880, 140);
            this.update_group.TabIndex = 25;
            this.update_group.TabStop = false;
            this.update_group.Text = "修改";
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Location = new System.Drawing.Point(696, 98);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(62, 18);
            this.name_label.TabIndex = 18;
            this.name_label.Text = "姓名：";
            // 
            // rid_label
            // 
            this.rid_label.AutoSize = true;
            this.rid_label.Location = new System.Drawing.Point(444, 98);
            this.rid_label.Name = "rid_label";
            this.rid_label.Size = new System.Drawing.Size(80, 18);
            this.rid_label.TabIndex = 17;
            this.rid_label.Text = "我的卡号";
            // 
            // GetInfo
            // 
            this.GetInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GetInfo.Location = new System.Drawing.Point(1106, 112);
            this.GetInfo.Name = "GetInfo";
            this.GetInfo.RowHeadersWidth = 62;
            this.GetInfo.RowTemplate.Height = 30;
            this.GetInfo.Size = new System.Drawing.Size(240, 150);
            this.GetInfo.TabIndex = 41;
            // 
            // ReaderUpdate_reader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1148, 493);
            this.Controls.Add(this.GetInfo);
            this.Controls.Add(this.reset_btn);
            this.Controls.Add(this.update_cancel);
            this.Controls.Add(this.update_confirm);
            this.Controls.Add(this.update_group);
            this.Name = "ReaderUpdate_reader";
            this.Text = "ReaderUpdate_reader";
            this.Load += new System.EventHandler(this.ReaderUpdate_reader_Load);
            this.update_group.ResumeLayout(false);
            this.update_group.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GetInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox rtel_text;
        private System.Windows.Forms.Label l8;
        private System.Windows.Forms.ComboBox rsex_combo;
        private System.Windows.Forms.TextBox rworkplace_text;
        private System.Windows.Forms.TextBox rjob_text;
        private System.Windows.Forms.Label Available_sum;
        private System.Windows.Forms.Label Already_sum;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label l3;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.Button update_cancel;
        private System.Windows.Forms.Button update_confirm;
        private System.Windows.Forms.GroupBox update_group;
        private System.Windows.Forms.DataGridView GetInfo;
        private System.Windows.Forms.Label rid_label;
        private System.Windows.Forms.Label name_label;
    }
}