﻿namespace DataBase_Library
{
    partial class ReaderUpdate_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reset_btn = new System.Windows.Forms.Button();
            this.rsex_combo = new System.Windows.Forms.ComboBox();
            this.ravailable_text = new System.Windows.Forms.TextBox();
            this.rworkplace_text = new System.Windows.Forms.TextBox();
            this.ralready_text = new System.Windows.Forms.TextBox();
            this.rname_text = new System.Windows.Forms.TextBox();
            this.rjob_text = new System.Windows.Forms.TextBox();
            this.l7 = new System.Windows.Forms.Label();
            this.l6 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.l3 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.update_cancel = new System.Windows.Forms.Button();
            this.update_confirm = new System.Windows.Forms.Button();
            this.update_group = new System.Windows.Forms.GroupBox();
            this.rtel_text = new System.Windows.Forms.TextBox();
            this.l8 = new System.Windows.Forms.Label();
            this.rid_text = new System.Windows.Forms.TextBox();
            this.l1 = new System.Windows.Forms.Label();
            this.OverDueInfo_btn = new System.Windows.Forms.Button();
            this.OverDueInfoData = new System.Windows.Forms.DataGridView();
            this.update_group.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OverDueInfoData)).BeginInit();
            this.SuspendLayout();
            // 
            // reset_btn
            // 
            this.reset_btn.Location = new System.Drawing.Point(845, 261);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(75, 33);
            this.reset_btn.TabIndex = 18;
            this.reset_btn.Text = "复位";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // rsex_combo
            // 
            this.rsex_combo.FormattingEnabled = true;
            this.rsex_combo.Items.AddRange(new object[] {
            "男",
            "女"});
            this.rsex_combo.Location = new System.Drawing.Point(528, 30);
            this.rsex_combo.Name = "rsex_combo";
            this.rsex_combo.Size = new System.Drawing.Size(112, 26);
            this.rsex_combo.TabIndex = 14;
            // 
            // ravailable_text
            // 
            this.ravailable_text.Location = new System.Drawing.Point(528, 88);
            this.ravailable_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ravailable_text.Name = "ravailable_text";
            this.ravailable_text.Size = new System.Drawing.Size(112, 28);
            this.ravailable_text.TabIndex = 13;
            // 
            // rworkplace_text
            // 
            this.rworkplace_text.Location = new System.Drawing.Point(734, 24);
            this.rworkplace_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rworkplace_text.Name = "rworkplace_text";
            this.rworkplace_text.Size = new System.Drawing.Size(112, 28);
            this.rworkplace_text.TabIndex = 12;
            // 
            // ralready_text
            // 
            this.ralready_text.Location = new System.Drawing.Point(308, 88);
            this.ralready_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ralready_text.Name = "ralready_text";
            this.ralready_text.Size = new System.Drawing.Size(112, 28);
            this.ralready_text.TabIndex = 10;
            // 
            // rname_text
            // 
            this.rname_text.Location = new System.Drawing.Point(104, 88);
            this.rname_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rname_text.Name = "rname_text";
            this.rname_text.Size = new System.Drawing.Size(112, 28);
            this.rname_text.TabIndex = 9;
            // 
            // rjob_text
            // 
            this.rjob_text.Location = new System.Drawing.Point(308, 31);
            this.rjob_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rjob_text.Name = "rjob_text";
            this.rjob_text.Size = new System.Drawing.Size(112, 28);
            this.rjob_text.TabIndex = 8;
            // 
            // l7
            // 
            this.l7.AutoSize = true;
            this.l7.Location = new System.Drawing.Point(447, 92);
            this.l7.Name = "l7";
            this.l7.Size = new System.Drawing.Size(80, 18);
            this.l7.TabIndex = 6;
            this.l7.Text = "可借数量";
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Location = new System.Drawing.Point(223, 92);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(80, 18);
            this.l6.TabIndex = 5;
            this.l6.Text = "已借数量";
            // 
            // l5
            // 
            this.l5.AutoSize = true;
            this.l5.Location = new System.Drawing.Point(55, 92);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(44, 18);
            this.l5.TabIndex = 4;
            this.l5.Text = "姓名";
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Location = new System.Drawing.Point(656, 30);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(80, 18);
            this.l4.TabIndex = 3;
            this.l4.Text = "工作地点";
            // 
            // l3
            // 
            this.l3.AutoSize = true;
            this.l3.Location = new System.Drawing.Point(478, 33);
            this.l3.Name = "l3";
            this.l3.Size = new System.Drawing.Size(44, 18);
            this.l3.TabIndex = 2;
            this.l3.Text = "性别";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Location = new System.Drawing.Point(222, 34);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(80, 18);
            this.l2.TabIndex = 1;
            this.l2.Text = "工作职称";
            // 
            // update_cancel
            // 
            this.update_cancel.Location = new System.Drawing.Point(630, 339);
            this.update_cancel.Name = "update_cancel";
            this.update_cancel.Size = new System.Drawing.Size(118, 43);
            this.update_cancel.TabIndex = 23;
            this.update_cancel.Text = "取消";
            this.update_cancel.UseVisualStyleBackColor = true;
            this.update_cancel.Click += new System.EventHandler(this.update_cancel_Click);
            // 
            // update_confirm
            // 
            this.update_confirm.Location = new System.Drawing.Point(253, 339);
            this.update_confirm.Name = "update_confirm";
            this.update_confirm.Size = new System.Drawing.Size(118, 43);
            this.update_confirm.TabIndex = 22;
            this.update_confirm.Text = "确认";
            this.update_confirm.UseVisualStyleBackColor = true;
            this.update_confirm.Click += new System.EventHandler(this.update_confirm_Click);
            // 
            // update_group
            // 
            this.update_group.Controls.Add(this.rtel_text);
            this.update_group.Controls.Add(this.l8);
            this.update_group.Controls.Add(this.rsex_combo);
            this.update_group.Controls.Add(this.ravailable_text);
            this.update_group.Controls.Add(this.rworkplace_text);
            this.update_group.Controls.Add(this.ralready_text);
            this.update_group.Controls.Add(this.rname_text);
            this.update_group.Controls.Add(this.rjob_text);
            this.update_group.Controls.Add(this.rid_text);
            this.update_group.Controls.Add(this.l7);
            this.update_group.Controls.Add(this.l6);
            this.update_group.Controls.Add(this.l5);
            this.update_group.Controls.Add(this.l4);
            this.update_group.Controls.Add(this.l3);
            this.update_group.Controls.Add(this.l2);
            this.update_group.Controls.Add(this.l1);
            this.update_group.Location = new System.Drawing.Point(46, 114);
            this.update_group.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_group.Name = "update_group";
            this.update_group.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_group.Size = new System.Drawing.Size(880, 140);
            this.update_group.TabIndex = 21;
            this.update_group.TabStop = false;
            this.update_group.Text = "修改";
            // 
            // rtel_text
            // 
            this.rtel_text.Location = new System.Drawing.Point(737, 88);
            this.rtel_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtel_text.Name = "rtel_text";
            this.rtel_text.Size = new System.Drawing.Size(112, 28);
            this.rtel_text.TabIndex = 16;
            // 
            // l8
            // 
            this.l8.AutoSize = true;
            this.l8.Location = new System.Drawing.Point(687, 91);
            this.l8.Name = "l8";
            this.l8.Size = new System.Drawing.Size(44, 18);
            this.l8.TabIndex = 15;
            this.l8.Text = "电话";
            // 
            // rid_text
            // 
            this.rid_text.Location = new System.Drawing.Point(104, 28);
            this.rid_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rid_text.Name = "rid_text";
            this.rid_text.Size = new System.Drawing.Size(112, 28);
            this.rid_text.TabIndex = 7;
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Location = new System.Drawing.Point(19, 34);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(80, 18);
            this.l1.TabIndex = 0;
            this.l1.Text = "读书卡号";
            // 
            // OverDueInfo_btn
            // 
            this.OverDueInfo_btn.Location = new System.Drawing.Point(68, 261);
            this.OverDueInfo_btn.Name = "OverDueInfo_btn";
            this.OverDueInfo_btn.Size = new System.Drawing.Size(228, 33);
            this.OverDueInfo_btn.TabIndex = 24;
            this.OverDueInfo_btn.Text = "查看该读者未还书籍信息";
            this.OverDueInfo_btn.UseVisualStyleBackColor = true;
            this.OverDueInfo_btn.Click += new System.EventHandler(this.OverDueInfo_btn_Click);
            // 
            // OverDueInfoData
            // 
            this.OverDueInfoData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OverDueInfoData.Location = new System.Drawing.Point(46, 413);
            this.OverDueInfoData.Name = "OverDueInfoData";
            this.OverDueInfoData.RowHeadersWidth = 62;
            this.OverDueInfoData.RowTemplate.Height = 30;
            this.OverDueInfoData.Size = new System.Drawing.Size(874, 150);
            this.OverDueInfoData.TabIndex = 25;
            // 
            // ReaderUpdate_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1029, 563);
            this.Controls.Add(this.OverDueInfoData);
            this.Controls.Add(this.OverDueInfo_btn);
            this.Controls.Add(this.reset_btn);
            this.Controls.Add(this.update_cancel);
            this.Controls.Add(this.update_confirm);
            this.Controls.Add(this.update_group);
            this.Name = "ReaderUpdate_admin";
            this.Text = "ReaderUpdate";
            this.Load += new System.EventHandler(this.ReaderUpdate_admin_Load);
            this.update_group.ResumeLayout(false);
            this.update_group.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OverDueInfoData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.ComboBox rsex_combo;
        private System.Windows.Forms.TextBox ravailable_text;
        private System.Windows.Forms.TextBox rworkplace_text;
        private System.Windows.Forms.TextBox ralready_text;
        private System.Windows.Forms.TextBox rname_text;
        private System.Windows.Forms.TextBox rjob_text;
        private System.Windows.Forms.Label l7;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label l3;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Button update_cancel;
        private System.Windows.Forms.Button update_confirm;
        private System.Windows.Forms.GroupBox update_group;
        private System.Windows.Forms.TextBox rtel_text;
        private System.Windows.Forms.Label l8;
        private System.Windows.Forms.TextBox rid_text;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Button OverDueInfo_btn;
        private System.Windows.Forms.DataGridView OverDueInfoData;
    }
}