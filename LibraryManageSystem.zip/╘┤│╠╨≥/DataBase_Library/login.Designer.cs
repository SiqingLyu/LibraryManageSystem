﻿namespace DataBase_Library
{
    partial class login
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.username_text = new System.Windows.Forms.TextBox();
            this.passwd_text = new System.Windows.Forms.TextBox();
            this.user_name = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.Label();
            this.login_btn = new System.Windows.Forms.Button();
            this.signin_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // username_text
            // 
            this.username_text.Location = new System.Drawing.Point(189, 129);
            this.username_text.Name = "username_text";
            this.username_text.Size = new System.Drawing.Size(156, 28);
            this.username_text.TabIndex = 0;
            // 
            // passwd_text
            // 
            this.passwd_text.Location = new System.Drawing.Point(449, 129);
            this.passwd_text.Name = "passwd_text";
            this.passwd_text.PasswordChar = '*';
            this.passwd_text.Size = new System.Drawing.Size(156, 28);
            this.passwd_text.TabIndex = 1;
            // 
            // user_name
            // 
            this.user_name.AutoSize = true;
            this.user_name.Location = new System.Drawing.Point(121, 132);
            this.user_name.Name = "user_name";
            this.user_name.Size = new System.Drawing.Size(62, 18);
            this.user_name.TabIndex = 2;
            this.user_name.Text = "用户名";
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.Location = new System.Drawing.Point(399, 132);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(44, 18);
            this.password.TabIndex = 3;
            this.password.Text = "密码";
            // 
            // login_btn
            // 
            this.login_btn.Location = new System.Drawing.Point(200, 267);
            this.login_btn.Name = "login_btn";
            this.login_btn.Size = new System.Drawing.Size(76, 42);
            this.login_btn.TabIndex = 4;
            this.login_btn.Text = "登录";
            this.login_btn.UseVisualStyleBackColor = true;
            this.login_btn.Click += new System.EventHandler(this.login_btn_Click);
            // 
            // signin_button
            // 
            this.signin_button.Location = new System.Drawing.Point(472, 267);
            this.signin_button.Name = "signin_button";
            this.signin_button.Size = new System.Drawing.Size(75, 41);
            this.signin_button.TabIndex = 5;
            this.signin_button.Text = "注册";
            this.signin_button.UseVisualStyleBackColor = true;
            this.signin_button.Click += new System.EventHandler(this.signin_button_Click);
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 398);
            this.Controls.Add(this.signin_button);
            this.Controls.Add(this.login_btn);
            this.Controls.Add(this.password);
            this.Controls.Add(this.user_name);
            this.Controls.Add(this.passwd_text);
            this.Controls.Add(this.username_text);
            this.Name = "login";
            this.Text = "6";
            this.Load += new System.EventHandler(this.login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox username_text;
        private System.Windows.Forms.TextBox passwd_text;
        private System.Windows.Forms.Label user_name;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Button login_btn;
        private System.Windows.Forms.Button signin_button;
    }
}

