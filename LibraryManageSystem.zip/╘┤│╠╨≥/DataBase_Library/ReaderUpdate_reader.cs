﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    public partial class ReaderUpdate_reader : Form
    {
        public string sql_default = String.Format("select * from Readers where rid = '{0}'", publicVar.currentRid.Trim());
        public string[] dateBefore = new string[8];

        public ReaderUpdate_reader()
        {

            InitializeComponent();
            string ridUstr = publicVar.currentRid;
            update_group.Text = "修改我的信息";
            GetInfo.Visible = false;
            //Console.WriteLine("\n\n调试中的debugNumber:语句：{0}\n\n", bookselect_admin);
            this.GetInfo.DataSource = DBoperations.Query(sql_default).Tables["ds"];
            publicVar.currentRid = GetInfo.Rows[0].Cells[0].Value.ToString().Trim();
           
            for (int i = 0; i < 8; i++)
            {
                dateBefore[i] = GetInfo.Rows[0].Cells[i].Value.ToString().Trim();
            }
            rid_label.Text = "我的卡号："+dateBefore[0];
            name_label.Text = "姓名："+dateBefore[1];
            rsex_combo.Text = dateBefore[2];
            rjob_text.Text = dateBefore[3];
            Available_sum.Text = "可借数量："+dateBefore[4];
            Already_sum.Text = "已借数量："+dateBefore[5];
            rworkplace_text.Text = dateBefore[6];
            rtel_text.Text = dateBefore[7];
        }

        private void l7_Click(object sender, EventArgs e)
        {

        }

        private void update_confirm_Click(object sender, EventArgs e)
        {
            int update_flag = 0;
            string updateInfo = "";

           
            string rsexStr = rsex_combo.Text.Trim();
            if (!String.Equals(rsexStr, dateBefore[2]))
            {
                updateInfo += "修改性别为" + rsexStr + ",\n";
                update_flag++;
            }
            string rjobStr = rjob_text.Text.Trim();
            if (!String.Equals(rjobStr, dateBefore[3]))
            {
                updateInfo += "修改工作职称为" + rjobStr + ",\n";
                update_flag++;
            }
           
            string rworkplaceStr = rworkplace_text.Text.Trim();
            if (!String.Equals(rworkplaceStr, dateBefore[6]))
            {
                updateInfo += "修改工作地点为" + rworkplaceStr + ",\n";
                update_flag++;
            }
            string rtelStr = rtel_text.Text.Trim();
            if (!String.Equals(rtelStr, dateBefore[7]))
            {
                updateInfo += "修改电话为" + rtelStr + ",\n";
                update_flag++;
            }
            if (update_flag == 0)
            {
                MessageBox.Show("未作出任何修改！", "重新修改");
                return;
            }
            string updateSql = String.Format("update Readers set rsex = '{0}', rjob = '{1}' ,rworkplace = '{2}' , rtel = '{3} 'where rid = '{4}'",
                                               rsexStr, rjobStr, rworkplaceStr, rtelStr, dateBefore[0]);
            if (MessageBox.Show(updateInfo, "确认修改？", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                if (DBoperations.ExecuteSql(updateSql) > 0) //rows > 0
                {
                    MessageBox.Show("修改成功");

                }
                else
                {
                    MessageBox.Show("修改失败！");
                }
            }
            else
            {
                return;
            }

            this.Dispose();

        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            rid_label.Text = "我的卡号：" + dateBefore[0];
            name_label.Text = "姓名：" + dateBefore[1];
            rsex_combo.Text = dateBefore[2];
            rjob_text.Text = dateBefore[3];
            Available_sum.Text = "可借数量：" + dateBefore[4];
            Already_sum.Text = "已借数量：" + dateBefore[5];
            rworkplace_text.Text = dateBefore[6];
            rtel_text.Text = dateBefore[7];
        }

        private void update_cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void ReaderUpdate_reader_Load(object sender, EventArgs e)
        {
            this.Text = "读者界面——个人信息修改";

        }
    }
}
