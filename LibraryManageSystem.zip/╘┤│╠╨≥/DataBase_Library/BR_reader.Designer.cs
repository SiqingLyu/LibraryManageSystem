﻿namespace DataBase_Library
{
    partial class BR_reader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BR = new System.Windows.Forms.Button();
            this.Readers = new System.Windows.Forms.Button();
            this.Books = new System.Windows.Forms.Button();
            this.reset_btn = new System.Windows.Forms.Button();
            this.ISBNum_text = new System.Windows.Forms.TextBox();
            this.select_btn = new System.Windows.Forms.Button();
            this.selectresultsgroupBox6 = new System.Windows.Forms.GroupBox();
            this.refresh_btn = new System.Windows.Forms.Button();
            this.selectresults = new System.Windows.Forms.DataGridView();
            this.bookname_text = new System.Windows.Forms.TextBox();
            this.writerlabel6 = new System.Windows.Forms.Label();
            this.bookname = new System.Windows.Forms.Label();
            this.selectconditionsgroupBox6 = new System.Windows.Forms.GroupBox();
            this.return_btn = new System.Windows.Forms.Button();
            this.BooksIndue_btn = new System.Windows.Forms.Button();
            this.PayFine = new System.Windows.Forms.Button();
            this.selectresultsgroupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.selectresults)).BeginInit();
            this.selectconditionsgroupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // BR
            // 
            this.BR.Location = new System.Drawing.Point(232, 49);
            this.BR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BR.Name = "BR";
            this.BR.Size = new System.Drawing.Size(181, 29);
            this.BR.TabIndex = 36;
            this.BR.Text = "我的借阅图书信息";
            this.BR.UseVisualStyleBackColor = true;
            this.BR.Click += new System.EventHandler(this.BR_Click);
            // 
            // Readers
            // 
            this.Readers.Location = new System.Drawing.Point(47, 50);
            this.Readers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Readers.Name = "Readers";
            this.Readers.Size = new System.Drawing.Size(98, 28);
            this.Readers.TabIndex = 34;
            this.Readers.Text = "读者信息";
            this.Readers.UseVisualStyleBackColor = true;
            this.Readers.Click += new System.EventHandler(this.Readers_Click);
            // 
            // Books
            // 
            this.Books.Location = new System.Drawing.Point(142, 50);
            this.Books.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Books.Name = "Books";
            this.Books.Size = new System.Drawing.Size(98, 28);
            this.Books.TabIndex = 35;
            this.Books.Text = "图书信息";
            this.Books.UseVisualStyleBackColor = true;
            this.Books.Click += new System.EventHandler(this.Books_Click);
            // 
            // reset_btn
            // 
            this.reset_btn.Location = new System.Drawing.Point(774, 50);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(85, 33);
            this.reset_btn.TabIndex = 30;
            this.reset_btn.Text = "复位";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // ISBNum_text
            // 
            this.ISBNum_text.Location = new System.Drawing.Point(306, 26);
            this.ISBNum_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ISBNum_text.Name = "ISBNum_text";
            this.ISBNum_text.Size = new System.Drawing.Size(112, 28);
            this.ISBNum_text.TabIndex = 8;
            // 
            // select_btn
            // 
            this.select_btn.Location = new System.Drawing.Point(386, 234);
            this.select_btn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.select_btn.Name = "select_btn";
            this.select_btn.Size = new System.Drawing.Size(84, 28);
            this.select_btn.TabIndex = 33;
            this.select_btn.Text = "查询";
            this.select_btn.UseVisualStyleBackColor = true;
            this.select_btn.Click += new System.EventHandler(this.select_btn_Click);
            // 
            // selectresultsgroupBox6
            // 
            this.selectresultsgroupBox6.Controls.Add(this.refresh_btn);
            this.selectresultsgroupBox6.Controls.Add(this.selectresults);
            this.selectresultsgroupBox6.Location = new System.Drawing.Point(41, 270);
            this.selectresultsgroupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresultsgroupBox6.Name = "selectresultsgroupBox6";
            this.selectresultsgroupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresultsgroupBox6.Size = new System.Drawing.Size(824, 310);
            this.selectresultsgroupBox6.TabIndex = 32;
            this.selectresultsgroupBox6.TabStop = false;
            this.selectresultsgroupBox6.Text = "查询结果";
            // 
            // refresh_btn
            // 
            this.refresh_btn.Location = new System.Drawing.Point(731, 0);
            this.refresh_btn.Name = "refresh_btn";
            this.refresh_btn.Size = new System.Drawing.Size(85, 32);
            this.refresh_btn.TabIndex = 18;
            this.refresh_btn.Text = "刷新";
            this.refresh_btn.UseVisualStyleBackColor = true;
            this.refresh_btn.Click += new System.EventHandler(this.refresh_btn_Click);
            // 
            // selectresults
            // 
            this.selectresults.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.selectresults.Location = new System.Drawing.Point(6, 28);
            this.selectresults.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectresults.Name = "selectresults";
            this.selectresults.RowHeadersWidth = 51;
            this.selectresults.RowTemplate.Height = 27;
            this.selectresults.Size = new System.Drawing.Size(810, 274);
            this.selectresults.TabIndex = 0;
            // 
            // bookname_text
            // 
            this.bookname_text.Location = new System.Drawing.Point(122, 26);
            this.bookname_text.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bookname_text.Name = "bookname_text";
            this.bookname_text.Size = new System.Drawing.Size(112, 28);
            this.bookname_text.TabIndex = 7;
            // 
            // writerlabel6
            // 
            this.writerlabel6.AutoSize = true;
            this.writerlabel6.Location = new System.Drawing.Point(240, 32);
            this.writerlabel6.Name = "writerlabel6";
            this.writerlabel6.Size = new System.Drawing.Size(62, 18);
            this.writerlabel6.TabIndex = 1;
            this.writerlabel6.Text = "ISBN号";
            // 
            // bookname
            // 
            this.bookname.AutoSize = true;
            this.bookname.Location = new System.Drawing.Point(37, 32);
            this.bookname.Name = "bookname";
            this.bookname.Size = new System.Drawing.Size(44, 18);
            this.bookname.TabIndex = 0;
            this.bookname.Text = "书名";
            // 
            // selectconditionsgroupBox6
            // 
            this.selectconditionsgroupBox6.Controls.Add(this.ISBNum_text);
            this.selectconditionsgroupBox6.Controls.Add(this.bookname_text);
            this.selectconditionsgroupBox6.Controls.Add(this.writerlabel6);
            this.selectconditionsgroupBox6.Controls.Add(this.bookname);
            this.selectconditionsgroupBox6.Location = new System.Drawing.Point(41, 86);
            this.selectconditionsgroupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectconditionsgroupBox6.Name = "selectconditionsgroupBox6";
            this.selectconditionsgroupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.selectconditionsgroupBox6.Size = new System.Drawing.Size(824, 86);
            this.selectconditionsgroupBox6.TabIndex = 31;
            this.selectconditionsgroupBox6.TabStop = false;
            this.selectconditionsgroupBox6.Text = "查询条件";
            // 
            // return_btn
            // 
            this.return_btn.Location = new System.Drawing.Point(393, 587);
            this.return_btn.Name = "return_btn";
            this.return_btn.Size = new System.Drawing.Size(77, 35);
            this.return_btn.TabIndex = 38;
            this.return_btn.Text = "还书";
            this.return_btn.UseVisualStyleBackColor = true;
            this.return_btn.Click += new System.EventHandler(this.return_btn_Click);
            // 
            // BooksIndue_btn
            // 
            this.BooksIndue_btn.Location = new System.Drawing.Point(701, 587);
            this.BooksIndue_btn.Name = "BooksIndue_btn";
            this.BooksIndue_btn.Size = new System.Drawing.Size(109, 35);
            this.BooksIndue_btn.TabIndex = 40;
            this.BooksIndue_btn.Text = "到期图书";
            this.BooksIndue_btn.UseVisualStyleBackColor = true;
            this.BooksIndue_btn.Click += new System.EventHandler(this.BooksIndue_btn_Click);
            // 
            // PayFine
            // 
            this.PayFine.Location = new System.Drawing.Point(81, 587);
            this.PayFine.Name = "PayFine";
            this.PayFine.Size = new System.Drawing.Size(109, 35);
            this.PayFine.TabIndex = 41;
            this.PayFine.Text = "缴纳罚款";
            this.PayFine.UseVisualStyleBackColor = true;
            this.PayFine.Click += new System.EventHandler(this.PayFine_Click);
            // 
            // BR_reader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(906, 629);
            this.Controls.Add(this.PayFine);
            this.Controls.Add(this.BooksIndue_btn);
            this.Controls.Add(this.return_btn);
            this.Controls.Add(this.BR);
            this.Controls.Add(this.Readers);
            this.Controls.Add(this.Books);
            this.Controls.Add(this.reset_btn);
            this.Controls.Add(this.select_btn);
            this.Controls.Add(this.selectresultsgroupBox6);
            this.Controls.Add(this.selectconditionsgroupBox6);
            this.Name = "BR_reader";
            this.Text = "BR_reader";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BR_reader_FormClosing);
            this.Load += new System.EventHandler(this.BR_reader_Load);
            this.selectresultsgroupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.selectresults)).EndInit();
            this.selectconditionsgroupBox6.ResumeLayout(false);
            this.selectconditionsgroupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BR;
        private System.Windows.Forms.Button Readers;
        private System.Windows.Forms.Button Books;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.TextBox ISBNum_text;
        private System.Windows.Forms.Button select_btn;
        private System.Windows.Forms.GroupBox selectresultsgroupBox6;
        private System.Windows.Forms.Button refresh_btn;
        private System.Windows.Forms.DataGridView selectresults;
        private System.Windows.Forms.TextBox bookname_text;
        private System.Windows.Forms.Label writerlabel6;
        private System.Windows.Forms.Label bookname;
        private System.Windows.Forms.GroupBox selectconditionsgroupBox6;
        private System.Windows.Forms.Button return_btn;
        private System.Windows.Forms.Button BooksIndue_btn;
        private System.Windows.Forms.Button PayFine;
    }
}