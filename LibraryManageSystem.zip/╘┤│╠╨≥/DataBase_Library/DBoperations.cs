﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBase_Library
{
    class DBoperations
    {
        public static DataSet Query(string sql) //查询
        {

            DataSet ds = new DataSet();
            try
            {
                SqlDataAdapter command = new SqlDataAdapter(sql, publicVar.currentConnection);
                command.Fill(ds, "ds");
            }
            catch (SqlException e)
            {
                if (MessageBox.Show(e.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error) == DialogResult.OK)
                    return ds;
            }
            return ds;
        }

        public static int ExecuteSql(String sql) //增删改
        {
            SqlCommand cmd = new SqlCommand(sql, publicVar.currentConnection);
            try
            {
                int rows = cmd.ExecuteNonQuery();
                
                return rows;
            }
            catch (SqlException e)
            {
                MessageBox.Show(e.Message, "错误！", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return -1;
            }
        }
    }
}
